<?php
	$title = '';
	$subtitle = '';		
	
	if(is_single()){
		$output = '';
		$categories = get_the_category(get_the_ID());
		$separator = ', ';
		$categories_output = '';
		if ( ! empty( $categories ) ) {
			foreach( $categories as $category ) {
				$output .= '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '" alt="' . sprintf( esc_attr__( 'View all posts in %s', 'gocourier' ), $category->name ) . '">' . esc_html( $category->name ) . '</a>' . $separator;
			}
			$categories_output = trim( $output, $separator );
		}
		$title = (function_exists('ot_get_option'))? ot_get_option( 'blog_title', '' ) : '';
		$subtitle = '<p>'.get_the_title().' ' .esc_html__('- In: ', 'gocourier'). $categories_output . '</p>'; ;
	}
	elseif( is_home() ){		
		$title = (function_exists('ot_get_option'))? ot_get_option( 'blog_title', '' ) : '';
		$subtitle = (function_exists('ot_get_option'))? ot_get_option( 'blog_subtitle', '' ) : '';
	}
	elseif ( is_category() ){
		$title = esc_html__( 'Category Archives: ', 'gocourier' ).single_cat_title( '', false );
		if ( category_description() ) :
		$subtitle = category_description();
		endif;
	}
	elseif(is_search()){
		$title = esc_html__('Search Result', 'gocourier');
		$subtitle = esc_html__( 'This is a Search Results Page for: '. get_search_query(), 'gocourier' );
	}
	elseif ( is_author() ){
		$title = esc_html__( 'Author Archives: ', 'gocourier' ).'' . get_the_author() . '';
		if ( category_description() ) :
		$subtitle = category_description();
		endif;
	} 
	elseif( is_tag() ) {
		$title = esc_html__( 'Tag Archives: ', 'gocourier' ).single_tag_title( '', false );
		if ( tag_description() ) :
		$subtitle = tag_description();
		endif;
	}
	elseif ( is_archive() ){	
			
		if ( is_day() ) :
			$title =  esc_html__( 'Daily Archives: ', 'gocourier' ).'' . get_the_date() . '';
		elseif ( is_month() ) :
			$title = esc_html__( 'Monthly Archives: ', 'gocourier' ). '' . get_the_date( esc_html_x( 'F Y', 'monthly archives date format', 'gocourier' ) ) . '' ;
		elseif ( is_year() ) :
			$title = esc_html__( 'Yearly Archives: ', 'gocourier' ).'' . get_the_date( esc_html_x( 'Y', 'yearly archives date format', 'gocourier' ) ) . '' ;
		else :
			$title = esc_html__( 'Archives', 'gocourier' );
		endif;
	} 	
	 elseif(is_404()){
		$title = esc_html__('Not Found', 'gocourier');
		$subtitle = esc_html__( 'Sorry page not found..', 'gocourier');
	}
	elseif( is_page() ){
		$title = get_the_title();
		$subtitle = tag_description();
		$custom_title = get_post_meta( get_the_ID(), 'custom_title', true );
		if( $custom_title == 'on' ){
			$alt_title = get_post_meta( get_the_ID(), 'title', true );
			$title = ( $alt_title != '' )? $alt_title : $title;
	
			$alt_subtitle = get_post_meta( get_the_ID(), 'subtitle', true );
			$subtitle = ( $alt_subtitle != '' )? $alt_subtitle : $subtitle;
		}
	}
	else {
		$title = get_the_title();
	}
	
	if(class_exists( 'woocommerce' )){
		if(is_woocommerce()){
			$title = (function_exists('ot_get_option'))? ot_get_option( 'shop_title', '' ) : '';
			$subtitle = (function_exists('ot_get_option'))? ot_get_option( 'shop_subtitle', '' ) : '';
		}
		if(is_product()){
			$title = get_the_title();
			$subtitle = (function_exists('ot_get_option'))? ot_get_option( 'shop_subtitle', '' ) : '';
		}
	}
?>
<div class="topheader">
<h1><?php echo esc_html($title); ?></h1>
<p><?php echo wp_kses($subtitle, array('a' => array('href' => array(),'alt' => array()) )); ?></p>
<?php 
$show_breadcrumbs =  (function_exists('ot_get_option'))? ot_get_option( 'show_breadcrumbs', 'on' ) : 'on';
if($show_breadcrumbs == 'on'):
?>
</div>

<?php gocourier_breadcrumbs(); ?>

<?php endif; ?>

