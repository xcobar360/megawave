jQuery(document).ready(function( $ ) {
	"use strict";
	
	/*------- Preloader --------*/
    $(window).bind("load", function () {
        $('#preloader').delay(1000).fadeOut(200);

    });
	
	$(window).scroll(function () {
		/*------- Scroll To Top --------*/
		if ($(this).scrollTop() > 100) {
			$('.to-top').css({bottom: '10px'});
		}
		else {
			$('.to-top').css({bottom: '-150px'});
		}
	
	});
	
	(function () {
        $('.to-top').click(function () {
            $('html, body').animate({scrollTop: 0}, 800);
            return false;
        });
    }());
		
	$('#wrapper p').each(function() {
        var $this = jQuery(this);
        if($this.html().replace(/\s|&nbsp;/g, '').length == 0) {
            $this.remove();
        }
    });
	
	(function () {
        if ($(window).width() > 760) {
            $(".header-sticky").sticky({topSpacing: 0});
        }
    }());
	
	var url = $('.slim-wrap').data('image');
	var homelink = $('.slim-wrap').data('homelink');
	$('.slim-wrap ul.menu-items').slimmenu({
        resizeWidth: '1000',
        collapserTitle: '<a href="'+homelink+'"><img src="'+url+'" alt="" /></a>',
        easingEffect:'easeInOutQuint',
        animSpeed:'medium',
        indentChildren: true,
        childrenIndenter: '&raquo;'
    });

    //Vimeo responsive
    $(".page-content .shop-box").fitVids();

});