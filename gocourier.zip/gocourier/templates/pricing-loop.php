<?php $pricing_style = $posts->data['style']; ?>
<div class="ts-pricing pricing-tables text-center row <?php echo esc_attr($pricing_style); ?>">
	<?php
		// Posts are found
		if ( $posts->have_posts() ) {
			while ( $posts->have_posts() ) :
				$posts->the_post();
				global $post;
				?>
                
                    <?php 
					$featured = get_post_meta( get_the_ID(), 'featured', true );
					$featured_class = ( $featured == 'off' )? 'featured-off' : 'featured-on';
					?>
                    <div id="ts-pricing-<?php the_ID(); ?>" class="col-md-4 col-sm-6 col-xs-12 <?php echo esc_attr($featured_class); ?>">
                    	<div class="pricing-box transition">
                             
                            <div class="pricing-price">
                            	<?php if($pricing_style == 'style_2'): ?>
                                <div class="pricing-header">
                                    <?php the_title( sprintf( '<h3>' ), '</h3>' ); ?>
                                </div>
                                <?php endif; ?>
                            	<?php
                                $price_currency = get_post_meta( get_the_ID(), 'price_currency', true );
								$price_text = get_post_meta( get_the_ID(), 'price_text', true );
								?>
                                <p><?php echo esc_html($price_currency); ?><?php echo esc_html($price_text); ?></p>
                            </div><!-- end price -->
                            <div class="pricing-desc text-center">
                                <p><?php the_content(); ?></p>
                            </div><!-- end desc -->
                            <?php if($pricing_style == 'default'): ?>
                            <div class="pricing-header">
                            	<?php the_title( sprintf( '<h3>' ), '</h3>' ); ?>
                            </div>
                            <?php endif; ?>
                            
                            <div class="pricing-description">                               
                                <?php 
								$feature_info = get_post_meta( get_the_ID(), 'feature_info', true );
								if(!empty($feature_info)):
								foreach( $feature_info as $value ):
								?>
                                    <h4 class="panel-title">
                                        <?php echo esc_html($value['title']); ?>
                                        <span><?php echo esc_html($value['feature_text']); ?></span>                                           
                                    </h4>
                                <?php
								endforeach;
								endif; ?>
                            </div><!-- end panel-group -->
                            
                            <div class="pricing-footer text-center">
                            	<?php 
								$button_link = get_post_meta( get_the_ID(), 'button_link', true );
								$button_text = get_post_meta( get_the_ID(), 'button_text', true );
								?>
                                <a href="<?php echo esc_url($button_link); ?>" class="pricing-button transition"><?php echo esc_html($button_text); ?> <i class="fa fa-arrow-right transition" aria-hidden="true"></i>
</a>
                            </div><!-- end desc -->
                        </div>
                    </div>

				<?php
			endwhile;
		}
		// Posts not found
		else {
			echo '<h3>' . esc_html__( 'Pricing not found', 'gocourier' ) . '</h3>';
		}
	?>
</div>