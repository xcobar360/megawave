<div class="ts-posts ts-posts-default-loop row">
	<?php
		// Posts are found
		if ( $posts->have_posts() ) {
			while ( $posts->have_posts() ) :
				$posts->the_post();
				global $post;
				?>
                    <div id="ts-post-<?php the_ID(); ?>" class="col-md-4 col-sm-6 col-xs-12">
                       <div class="shop-box">
                            <div class="shop-image entry">
                            	<?php if ( has_post_thumbnail() ) : ?>
                                <a href="<?php echo esc_url(get_permalink()); ?>"><?php gocourier_post_thumb( 1000, 600 ); ?></a>
                            <?php endif; ?>
                                <div class="magnifier">
                                    <div class="shop-buttons">
                                    	<?php $readmore_text = (function_exists('ot_get_option'))? ot_get_option( 'readmore_text', 'read more' ) : 'read more'; ?>
                                        <a class="btn btn-white" href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark"><?php echo esc_html($readmore_text); ?></a>
                                    </div>
                                </div><!-- end magnifier -->
                            </div>
                            <div class="shop-title">
                            	<?php the_title( sprintf( '<h3><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>
                            </div><!-- end blog-title -->
                            <div class="meta">
                                <?php
								$categories_list = get_the_category_list( esc_html_x( ', ', 'Used between list items, there is a comma.', 'gocourier' ) );
								if ( $categories_list && gocourier_categorized_blog() ): ?>
								<?php printf( '<span>%1$s </span>%2$s</span>', esc_html__( 'In : ', 'gocourier' ), $categories_list ); ?>
								<?php
								endif;
								?>
                                <span><?php echo esc_html__('Comments : ', 'gocourier'); ?><?php comments_number( '0', '1', '%' ); ?></span>
                                <span><?php echo esc_html__('Date : ', 'gocourier'); ?><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo get_the_date( 'd M Y' ); ?></a></span>
                            </div><!-- end meta -->
                            <div class="blog-desc-small">
                                <p><?php the_excerpt(); ?></p>
                            </div>
                        </div><!-- end blog-wrap -->
                    </div>
				<?php
			endwhile;
		}
		// Posts not found
		else {
			echo '<h4>' . esc_html__( 'Posts not found', 'gocourier' ) . '</h4>';
		}
	?>
</div>