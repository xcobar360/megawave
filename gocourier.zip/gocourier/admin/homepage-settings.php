<?php
/**
 * Initialize the meta boxes. 
 */
add_action( 'admin_init', 'gocourier_home_meta_boxes' );

function gocourier_home_meta_boxes() {
  if( function_exists( 'ot_get_option' ) ): 
  $my_meta_box = array(
    'id'        => 'gocourier_home_meta_box',
    'title'     => esc_html__('GoCourier Home Page Settings', 'gocourier'),
    'desc'      => '',
    'pages'     => array( 'page' ),
    'context'   => 'normal',
    'priority'  => 'high',
    'fields'    => array(     
     array(
        'id'          => 'home_header_settings',
        'label'       => esc_html__('Header Settings', 'gocourier'),      
        'type'        => 'tab',
        'operator'    => 'and'
      ), 
      array(
        'id'          => 'homepage_header_layout',
        'label'       => esc_html__( 'Header Style', 'gocourier' ),
        'desc'        => '',
        'std'         => 'default',
        'type'        => 'select',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
          array(
            'value'       => 'default',
            'label'       => esc_html__( 'Style 1', 'gocourier' ),
          ),
          array(
            'value'       => 'style_2',
            'label'       => esc_html__( 'Style 2', 'gocourier' ),
          ),
        )
      ),
    )
  );
  
  ot_register_meta_box( $my_meta_box );
  endif;  //if( function_exists( 'ot_get_option' ) ):
}
?>