<?php
//include theme options
include GOCOURIERTHEMEDIR . '/admin/theme-options/general.php';
include GOCOURIERTHEMEDIR . '/admin/theme-options/background.php';
include GOCOURIERTHEMEDIR . '/admin/theme-options/header.php';
include GOCOURIERTHEMEDIR . '/admin/theme-options/sidebar.php';
include GOCOURIERTHEMEDIR . '/admin/theme-options/footer.php';
include GOCOURIERTHEMEDIR . '/admin/theme-options/blog.php';
include GOCOURIERTHEMEDIR . '/admin/theme-options/woocommerce.php';
include GOCOURIERTHEMEDIR . '/admin/theme-options/calculate_cost.php';
include GOCOURIERTHEMEDIR . '/admin/theme-options/typography.php';
include GOCOURIERTHEMEDIR . '/admin/theme-options/styling.php';
/**
 * Initialize the custom theme options.
 */
add_action( 'admin_init', 'gocourier_theme_options', 1 );

/**
 * Build the custom settings & update OptionTree.
 */
function gocourier_theme_options() {
  
  /* OptionTree is not loaded yet */
  if ( ! function_exists( 'ot_settings_id' ) )
    return false;
    
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( ot_settings_id(), array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  //available option functions - return type array()
  $general_options = gocourier_general_options();
  $background_options = gocourier_background_options();
  $header_options = gocourier_header_options();
  $sidebar_options = gocourier_sidebar_options();
  $footer_options = gocourier_footer_options();
  $blog_options = gocourier_blog_options();
  $woocommerce_options = gocourier_woocommerce_options();
  $calculate_cost_options = gocourier_calculate_cost_options();
  $typography_options = gocourier_typography_options();
  $styling_options = gocourier_styling_options();

  //merge all available options
  $settings = array_merge( $general_options, $background_options, $header_options, $sidebar_options, $footer_options, $blog_options, $woocommerce_options, $calculate_cost_options, $typography_options, $styling_options ); 

  $custom_settings = array( 
    'contextual_help' => array( 
      'sidebar'       => ''
    ),
    'sections'        => array( 
      array(
        'id'          => 'general_options',
        'title'       => esc_html__( 'General Options', 'gocourier' )
      ),
      array(
        'id'          => 'background_options',
        'title'       => esc_html__( 'Background Options', 'gocourier' )
      ),
     array(
        'id'          => 'header_options',
        'title'       => esc_html__( 'Header Options', 'gocourier' )
      ),
      array(
        'id'          => 'footer_options',
        'title'       => esc_html__( 'Footer Options', 'gocourier' )
      ),
      array(
        'id'          => 'sidebar_option',
        'title'       => esc_html__( 'Sidebar Options', 'gocourier' )
      ),
      array(
        'id'          => 'blog_options',
        'title'       => esc_html__( 'Blog Options', 'gocourier' )
      ),
	  array(
        'id'          => 'woocommerce_options',
        'title'       => esc_html__( 'Woocommerce Options', 'gocourier' )
      ),
	  array(
        'id'          => 'calculate_cost_options',
        'title'       => esc_html__( 'Calculate Cost Options', 'gocourier' )
      ),
      array(
        'id'          => 'fonts',
        'title'       => esc_html__( 'Typography Options', 'gocourier' )
      ),
      array(
        'id'          => 'styling_options',
        'title'       => esc_html__( 'Styling Options', 'gocourier' )
      )
    ),
    'settings'        => $settings
  );
  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( ot_settings_id() . '_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( ot_settings_id(), $custom_settings ); 
  }
  
  /* Lets OptionTree know the UI Builder is being overridden */
  global $ot_has_custom_theme_options;
  $ot_has_custom_theme_options = true;

  return $custom_settings[ 'settings' ];  
}