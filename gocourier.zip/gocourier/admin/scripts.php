<?php
// Register Style
function gocourier_admin_styles() {

	wp_register_style( 'gocourier-style', GOCOURIERTHEMEURI. 'admin/assets/css/style.css', false, '1.0.0', 'all' );
	wp_enqueue_style( 'gocourier-style' );

}
// Hook into the 'admin_enqueue_scripts' action
add_action( 'admin_enqueue_scripts', 'gocourier_admin_styles' );

// Register Script
function gocourier_admin_scripts() {

	wp_register_script( 'gocourier-scripts', GOCOURIERTHEMEURI. 'admin/assets/js/scripts.js', array( 'jquery', 'wp-color-picker' ), false, true );
	wp_enqueue_script( 'gocourier-scripts' );

}
// Hook into the 'admin_enqueue_scripts' action
add_action( 'admin_enqueue_scripts', 'gocourier_admin_scripts' );
?>