<?php
function gocourier_woocommerce_options( $options = array() ){
	$options = array(
        array(
            'id'          => 'product_column',
            'label'       => esc_html__( 'Product column', 'gocourier' ),
            'desc'        => '',
            'std'         => '3',
            'type'        => 'numeric-slider',
            'section'     => 'woocommerce_options',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '1,4,1',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          
        ),
		array(
            'id'          => 'related_product',
            'label'       => esc_html__( 'Related product show in single product', 'gocourier' ),
            'desc'        => '',
            'std'         => '4',
            'type'        => 'numeric-slider',
            'section'     => 'woocommerce_options',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '1,10,1',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          
        ),
		array(
            'id'          => 'related_product_column',
            'label'       => esc_html__( 'Related Product column', 'gocourier' ),
            'desc'        => '',
            'std'         => '4',
            'type'        => 'numeric-slider',
            'section'     => 'woocommerce_options',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '1,4,1',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          
        ),
	  array(
        'id'          => 'shop_layout',
        'label'       => esc_html__( 'Shop layout', 'gocourier' ),
        'desc'        => '',
        'std'         => 'rs',
        'type'        => 'radio-image',
        'section'     => 'woocommerce_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
          array(
            'value'       => 'full',
            'label'       => esc_html__( 'Full width', 'gocourier' ),
            'src'         => OT_URL . '/assets/images/layout/full-width.png'
          ),
          array(
            'value'       => 'ls',
            'label'       => esc_html__( 'Left sidebar', 'gocourier' ),
            'src'         => OT_URL . '/assets/images/layout/left-sidebar.png'
          ),
          array(
            'value'       => 'rs',
            'label'       => esc_html__( 'Right sidebar', 'gocourier' ),
            'src'         => OT_URL . '/assets/images/layout/right-sidebar.png'
          )
        )
      ),
    array(
        'id'          => 'shop_layout_sidebar',
        'label'       => esc_html__( 'Select shop Sidebar', 'gocourier' ),
        'desc'        => '',
        'std'         => 'sidebar-1',
        'type'        => 'sidebar-select',
        'section'     => 'woocommerce_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => 'shop_layout:not(full)',
        'operator'    => 'and'
      ),
    array(
        'id'          => 'product_layout',
        'label'       => esc_html__( 'Product layout', 'gocourier' ),
        'desc'        => '',
        'std'         => 'full',
        'type'        => 'radio-image',
        'section'     => 'woocommerce_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array( 
          array(
            'value'       => 'full',
            'label'       => esc_html__( 'Full width', 'gocourier' ),
            'src'         => OT_URL . '/assets/images/layout/full-width.png'
          ),
          array(
            'value'       => 'ls',
            'label'       => esc_html__( 'Left sidebar', 'gocourier' ),
            'src'         => OT_URL . '/assets/images/layout/left-sidebar.png'
          ),
          array(
            'value'       => 'rs',
            'label'       => esc_html__( 'Right sidebar', 'gocourier' ),
            'src'         => OT_URL . '/assets/images/layout/right-sidebar.png'
          )
        )
      ),
    array(
        'id'          => 'product_layout_sidebar',
        'label'       => esc_html__( 'Product Sidebar', 'gocourier' ),
        'desc'        => '',
        'std'         => 'sidebar-1',
        'type'        => 'sidebar-select',
        'section'     => 'woocommerce_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => 'product_layout:not(full)',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'shop_title',
        'label'       => esc_html__( 'Shop Title', 'gocourier' ),
        'desc'        => esc_html__( 'Shop page title', 'gocourier' ),
        'std'         => 'Shopping',
        'type'        => 'text',
        'section'     => 'woocommerce_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
    array(
        'id'          => 'shop_subtitle',
        'label'       => esc_html__( 'Shop Subtitle', 'gocourier' ),
        'desc'        => esc_html__( 'Subtitle of shop and single product page', 'gocourier' ),
        'std'         => 'Listed below our awesome shop items',
        'type'        => 'text',
        'section'     => 'woocommerce_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'shop_archive_banner',
        'label'       => esc_html__( 'Shop Page Banner', 'gocourier' ),
        'desc'        => esc_html__( 'Banner of shop page', 'gocourier' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'woocommerce_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
    );

	return apply_filters( 'gocourier_woocommerce_options', $options );
}  
?>