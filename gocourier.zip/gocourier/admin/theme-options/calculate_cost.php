<?php
function gocourier_calculate_cost_options( $options = array() ){
	$options = array(
		array(
        'id'          => 'calculate_height',
        'label'       => esc_html__( 'Height Field', 'gocourier' ),
        'desc'        => '',
        'std'         => 'on',
        'type'        => 'on-off',
        'section'     => 'calculate_cost_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'calculate_width',
        'label'       => esc_html__( 'Width Field', 'gocourier' ),
        'desc'        => '',
        'std'         => 'on',
        'type'        => 'on-off',
        'section'     => 'calculate_cost_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'calculate_depth',
        'label'       => esc_html__( 'Depth Field', 'gocourier' ),
        'desc'        => '',
        'std'         => 'on',
        'type'        => 'on-off',
        'section'     => 'calculate_cost_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),	  
	  array(
        'id'          => 'calculate_cost',
        'label'       => esc_html__( 'Add Calculate Details', 'gocourier' ),
        'desc'        => '',
        'std'         => '',
        'type'        => 'list-item',
        'section'     => 'calculate_cost_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'settings'    => array(
            array(
            'id'          => 'calculate_country',
            'label'       => esc_html__('Select a Location', 'gocourier'),
            'desc'        => '',
            'std'         => '',
            'type'        => 'select',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and',
            'choices'     => array(
                array(
                    'value'       => 'AF',
                    'label'       => esc_html__('Afghanistan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AL',
                    'label'       => esc_html__('Albania', 'gocourier'),
                  ),
				  array(
                    'value'       => 'DZ',
                    'label'       => esc_html__('Algeria', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AS',
                    'label'       => esc_html__('American Samoa', 'gocourier'),
                  ),
                  array(
                    'value'       => 'AD',
                    'label'       => esc_html__('Andorra', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AO',
                    'label'       => esc_html__('Angola', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AI',
                    'label'       => esc_html__('Anguilla', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AQ',
                    'label'       => esc_html__('Antarctica', 'gocourier'),
                  ),
                  array(
                    'value'       => 'AG',
                    'label'       => esc_html__('Antigua and Barbuda', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AR',
                    'label'       => esc_html__('Argentina', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AM',
                    'label'       => esc_html__('Armenia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AW',
                    'label'       => esc_html__('Aruba', 'gocourier'),
                  ),
                  array(
                    'value'       => 'AU',
                    'label'       => esc_html__('Australia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AT',
                    'label'       => esc_html__('Austria', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AZ',
                    'label'       => esc_html__('Azerbaijan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BS',
                    'label'       => esc_html__('Bahamas', 'gocourier'),
                  ),
                  array(
                    'value'       => 'BH',
                    'label'       => esc_html__('Bahrain', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BD',
                    'label'       => esc_html__('Bangladesh', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BB',
                    'label'       => esc_html__('Barbados', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BY',
                    'label'       => esc_html__('Belarus', 'gocourier'),
                  ),
                  array(
                    'value'       => 'BE',
                    'label'       => esc_html__('Belgium', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BZ',
                    'label'       => esc_html__('Belize', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BJ',
                    'label'       => esc_html__('Benin', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BM',
                    'label'       => esc_html__('Bermuda', 'gocourier'),
                  ),
                  array(
                    'value'       => 'BT',
                    'label'       => esc_html__('Bhutan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BO',
                    'label'       => esc_html__('Bolivia, Plurinational State of', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BQ',
                    'label'       => esc_html__('Bonaire, Sint Eustatius and Saba', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BA',
                    'label'       => esc_html__('Bosnia and Herzegovina', 'gocourier'),
                  ),
                  array(
                    'value'       => 'BW',
                    'label'       => esc_html__('Botswana', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BV',
                    'label'       => esc_html__('Bouvet Island', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BR',
                    'label'       => esc_html__('Brazil', 'gocourier'),
                  ),
				  array(
                    'value'       => 'IO',
                    'label'       => esc_html__('British Indian Ocean Territory', 'gocourier'),
                  ),
                  array(
                    'value'       => 'BN',
                    'label'       => esc_html__('Brunei Darussalam', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BG',
                    'label'       => esc_html__('Bulgaria', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BF',
                    'label'       => esc_html__('Burkina Faso', 'gocourier'),
                  ),
				  array(
                    'value'       => 'BI',
                    'label'       => esc_html__('Burundi', 'gocourier'),
                  ),
                  array(
                    'value'       => 'KH',
                    'label'       => esc_html__('Cambodia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CM',
                    'label'       => esc_html__('Cameroon', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CA',
                    'label'       => esc_html__('Canada', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CV',
                    'label'       => esc_html__('Cape Verde', 'gocourier'),
                  ),
                  array(
                    'value'       => 'CF',
                    'label'       => esc_html__('Central African Republic', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TD',
                    'label'       => esc_html__('Chad', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CL',
                    'label'       => esc_html__('Chile', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CN',
                    'label'       => esc_html__('China', 'gocourier'),
                  ),
                  array(
                    'value'       => 'CX',
                    'label'       => esc_html__('Christmas Island', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CC',
                    'label'       => esc_html__('Cocos (Keeling) Islands', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CO',
                    'label'       => esc_html__('Colombia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'KM',
                    'label'       => esc_html__('Comoros', 'gocourier'),
                  ),
                  array(
                    'value'       => 'CG',
                    'label'       => esc_html__('Congo', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CD',
                    'label'       => esc_html__('Congo', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CK',
                    'label'       => esc_html__('Cook Islands', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CR',
                    'label'       => esc_html__('Costa Rica', 'gocourier'),
                  ),
				  array(
                    'value'       => 'HR',
                    'label'       => esc_html__('Croatia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CU',
                    'label'       => esc_html__('Cuba', 'gocourier'),
                  ),
                  array(
                    'value'       => 'CY',
                    'label'       => esc_html__('Cyprus', 'gocourier'),
                  ),
				  array(
                    'value'       => 'CZ',
                    'label'       => esc_html__('Czech Republic', 'gocourier'),
                  ),
				  array(
                    'value'       => 'DK',
                    'label'       => esc_html__('Denmark', 'gocourier'),
                  ),
				  array(
                    'value'       => 'DJ',
                    'label'       => esc_html__('Djibouti', 'gocourier'),
                  ),
                  array(
                    'value'       => 'DM',
                    'label'       => esc_html__('Dominica', 'gocourier'),
                  ),
				  array(
                    'value'       => 'DO',
                    'label'       => esc_html__('Dominican Republic', 'gocourier'),
                  ),
				  array(
                    'value'       => 'EC',
                    'label'       => esc_html__('Ecuador', 'gocourier'),
                  ),
				  array(
                    'value'       => 'EG',
                    'label'       => esc_html__('Egypt', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SV',
                    'label'       => esc_html__('El Salvador', 'gocourier'),
                  ),
                  array(
                    'value'       => 'GQ',
                    'label'       => esc_html__('Equatorial Guinea', 'gocourier'),
                  ),
				  array(
                    'value'       => 'ER',
                    'label'       => esc_html__('Eritrea', 'gocourier'),
                  ),
				  array(
                    'value'       => 'EE',
                    'label'       => esc_html__('Estonia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'ET',
                    'label'       => esc_html__('Ethiopia', 'gocourier'),
                  ),
                  array(
                    'value'       => 'FK',
                    'label'       => esc_html__('alkland Islands (Malvinas)', 'gocourier'),
                  ),
				  array(
                    'value'       => 'FO',
                    'label'       => esc_html__('Faroe Islands', 'gocourier'),
                  ),
				  array(
                    'value'       => 'FJ',
                    'label'       => esc_html__('Fiji', 'gocourier'),
                  ),
				  array(
                    'value'       => 'FI',
                    'label'       => esc_html__('Finland', 'gocourier'),
                  ),
                  array(
                    'value'       => 'FR',
                    'label'       => esc_html__('France', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GF',
                    'label'       => esc_html__('French Guiana', 'gocourier'),
                  ),
				  array(
                    'value'       => 'PE',
                    'label'       => esc_html__('French Polynesia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TF',
                    'label'       => esc_html__('French Southern Territories', 'gocourier'),
                  ),
                  array(
                    'value'       => 'GA',
                    'label'       => esc_html__('Gabon', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GM',
                    'label'       => esc_html__('Gambia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GE',
                    'label'       => esc_html__('Georgia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'DE',
                    'label'       => esc_html__('Germany', 'gocourier'),
                  ),
                  array(
                    'value'       => 'GH',
                    'label'       => esc_html__('Ghana', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GI',
                    'label'       => esc_html__('Gibraltar', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GR',
                    'label'       => esc_html__('Greecen', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GL',
                    'label'       => esc_html__('Greenland', 'gocourier'),
                  ),
                  array(
                    'value'       => 'GD',
                    'label'       => esc_html__('Grenada', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GP',
                    'label'       => esc_html__('Guadeloupe', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GU',
                    'label'       => esc_html__('Guam', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GT',
                    'label'       => esc_html__('Guatemala', 'gocourier'),
                  ),
                  array(
                    'value'       => 'GG',
                    'label'       => esc_html__('Guernsey', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GN',
                    'label'       => esc_html__('Guinea', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GW',
                    'label'       => esc_html__('Guinea-Bissau', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GY',
                    'label'       => esc_html__('Guyana', 'gocourier'),
                  ),
				  array(
                    'value'       => 'HT',
                    'label'       => esc_html__('Haiti', 'gocourier'),
                  ),
                  array(
                    'value'       => 'HM',
                    'label'       => esc_html__('Heard Island and McDonald Islands', 'gocourier'),
                  ),
				  array(
                    'value'       => 'VA',
                    'label'       => esc_html__('Holy See (Vatican City State)', 'gocourier'),
                  ),
				  array(
                    'value'       => 'HN',
                    'label'       => esc_html__('Honduras', 'gocourier'),
                  ),
				  array(
                    'value'       => 'HK',
                    'label'       => esc_html__('Hong Kong', 'gocourier'),
                  ),
                  array(
                    'value'       => 'HU',
                    'label'       => esc_html__('Hungary', 'gocourier'),
                  ),
				  array(
                    'value'       => 'IS',
                    'label'       => esc_html__('Iceland', 'gocourier'),
                  ),
				  array(
                    'value'       => 'IN',
                    'label'       => esc_html__('India', 'gocourier'),
                  ),
				  array(
                    'value'       => 'ID',
                    'label'       => esc_html__('Indonesia', 'gocourier'),
                  ),
                  array(
                    'value'       => 'IR',
                    'label'       => esc_html__('Iran', 'gocourier'),
                  ),
				  array(
                    'value'       => 'IQ',
                    'label'       => esc_html__('Iraq', 'gocourier'),
                  ),
				  array(
                    'value'       => 'IE',
                    'label'       => esc_html__('Ireland', 'gocourier'),
                  ),
				  array(
                    'value'       => 'IM',
                    'label'       => esc_html__('Isle of Man', 'gocourier'),
                  ),
                  array(
                    'value'       => 'IL',
                    'label'       => esc_html__('Israel', 'gocourier'),
                  ),
				  array(
                    'value'       => 'IT',
                    'label'       => esc_html__('Italy', 'gocourier'),
                  ),
				  array(
                    'value'       => 'JM',
                    'label'       => esc_html__('Jamaica', 'gocourier'),
                  ),
				  array(
                    'value'       => 'JP',
                    'label'       => esc_html__('Japan', 'gocourier'),
                  ),
                  array(
                    'value'       => 'JE',
                    'label'       => esc_html__('Jersey', 'gocourier'),
                  ),
				  array(
                    'value'       => 'JO',
                    'label'       => esc_html__('Jordan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'KZ',
                    'label'       => esc_html__('Kazakhstan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'KE',
                    'label'       => esc_html__('Kenya', 'gocourier'),
                  ),
                  array(
                    'value'       => 'KI',
                    'label'       => esc_html__('Kiribati', 'gocourier'),
                  ),
				  array(
                    'value'       => 'KP',
                    'label'       => esc_html__('Korea, Democratic Peoples Republic of', 'gocourier'),
                  ),
				  array(
                    'value'       => 'KR',
                    'label'       => esc_html__('Korea, Republic of', 'gocourier'),
                  ),
				  array(
                    'value'       => 'KW',
                    'label'       => esc_html__('Kuwait', 'gocourier'),
                  ),
                  array(
                    'value'       => 'KG',
                    'label'       => esc_html__('Kyrgyzstan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'LA',
                    'label'       => esc_html__('Lao Peoples Democratic Republic', 'gocourier'),
                  ),
				  array(
                    'value'       => 'LV',
                    'label'       => esc_html__('Latvia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'LB',
                    'label'       => esc_html__('Lebanon', 'gocourier'),
                  ),
				  array(
                    'value'       => 'LS',
                    'label'       => esc_html__('Lesotho', 'gocourier'),
                  ),
                  array(
                    'value'       => 'LR',
                    'label'       => esc_html__('Liberia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'LY',
                    'label'       => esc_html__('Libya', 'gocourier'),
                  ),
				  array(
                    'value'       => 'LI',
                    'label'       => esc_html__('Liechtenstein', 'gocourier'),
                  ),
				  array(
                    'value'       => 'LT',
                    'label'       => esc_html__('Lithuania', 'gocourier'),
                  ),
                  array(
                    'value'       => 'LU',
                    'label'       => esc_html__('Luxembourg', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MO',
                    'label'       => esc_html__('Macao', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MK',
                    'label'       => esc_html__('Macedonia, the former Yugoslav Republic of', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MG',
                    'label'       => esc_html__('Madagascar', 'gocourier'),
                  ),
                  array(
                    'value'       => 'MW',
                    'label'       => esc_html__('Malawi', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MY',
                    'label'       => esc_html__('Malaysia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MV',
                    'label'       => esc_html__('Maldives', 'gocourier'),
                  ),
				  array(
                    'value'       => 'ML',
                    'label'       => esc_html__('Mali', 'gocourier'),
                  ),
                  array(
                    'value'       => 'MT',
                    'label'       => esc_html__('Malta', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MH',
                    'label'       => esc_html__('Marshall Islands', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MQ',
                    'label'       => esc_html__('Martinique', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MR',
                    'label'       => esc_html__('Mauritania', 'gocourier'),
                  ),
                  array(
                    'value'       => 'MU',
                    'label'       => esc_html__('Mauritius', 'gocourier'),
                  ),
				  array(
                    'value'       => 'YT',
                    'label'       => esc_html__('Mayotte', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MX',
                    'label'       => esc_html__('Mexico', 'gocourier'),
                  ),
				  array(
                    'value'       => 'FM',
                    'label'       => esc_html__('Micronesia, Federated States of', 'gocourier'),
                  ),
                  array(
                    'value'       => 'MD',
                    'label'       => esc_html__('Moldova, Republic of', 'gocourier'),

                  ),
				  array(
                    'value'       => 'MC',
                    'label'       => esc_html__('Monaco', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MN',
                    'label'       => esc_html__('Mongolia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'ME',
                    'label'       => esc_html__('Montenegro', 'gocourier'),
                  ),
                  array(
                    'value'       => 'MS',
                    'label'       => esc_html__('Montserrat', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MA',
                    'label'       => esc_html__('Morocco', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MZ',
                    'label'       => esc_html__('Mozambique', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MM',
                    'label'       => esc_html__('Myanmar', 'gocourier'),
                  ),
				  array(
                    'value'       => 'NA',
                    'label'       => esc_html__('Namibia', 'gocourier'),
                  ),
                  array(
                    'value'       => 'NR',
                    'label'       => esc_html__('Nauru', 'gocourier'),
                  ),
				  array(
                    'value'       => 'NP',
                    'label'       => esc_html__('Nepal', 'gocourier'),
                  ),
				  array(
                    'value'       => 'NL',
                    'label'       => esc_html__('Netherlands', 'gocourier'),
                  ),
				  array(
                    'value'       => 'NC',
                    'label'       => esc_html__('New Caledonia', 'gocourier'),
                  ),
                  array(
                    'value'       => 'NZ',
                    'label'       => esc_html__('New Zealand', 'gocourier'),
                  ),
				  array(
                    'value'       => 'NI',
                    'label'       => esc_html__('Nicaragua', 'gocourier'),
                  ),
				  array(
                    'value'       => 'NE',
                    'label'       => esc_html__('Niger', 'gocourier'),
                  ),
				  array(
                    'value'       => 'NG',
                    'label'       => esc_html__('Nigeria', 'gocourier'),
                  ),
                  array(
                    'value'       => 'NU',
                    'label'       => esc_html__('Niue', 'gocourier'),
                  ),
				  array(
                    'value'       => 'NF',
                    'label'       => esc_html__('Norfolk Island', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MP',
                    'label'       => esc_html__('Northern Mariana Islands', 'gocourier'),
                  ),
				  array(
                    'value'       => 'NO',
                    'label'       => esc_html__('Norway', 'gocourier'),
                  ),
                  array(
                    'value'       => 'OM',
                    'label'       => esc_html__('Oman', 'gocourier'),
                  ),
				  array(
                    'value'       => 'PK',
                    'label'       => esc_html__('Pakistan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'PW',
                    'label'       => esc_html__('Palau', 'gocourier'),
                  ),
				  array(
                    'value'       => 'PS',
                    'label'       => esc_html__('Palestinian Territory, Occupied', 'gocourier'),
                  ),
                  array(
                    'value'       => 'PA',
                    'label'       => esc_html__('Panama', 'gocourier'),
                  ),
				  array(
                    'value'       => 'PG',
                    'label'       => esc_html__('Papua New Guinea', 'gocourier'),
                  ),
				  array(
                    'value'       => 'PY',
                    'label'       => esc_html__('Paraguay', 'gocourier'),
                  ),
				  array(
                    'value'       => 'PE',
                    'label'       => esc_html__('Peru', 'gocourier'),
                  ),
                  array(
                    'value'       => 'PH',
                    'label'       => esc_html__('Philippines', 'gocourier'),

                  ),
				  array(
                    'value'       => 'PN',
                    'label'       => esc_html__('Pitcairn', 'gocourier'),
                  ),
				  array(
                    'value'       => 'PL',
                    'label'       => esc_html__('Poland', 'gocourier'),
                  ),
				  array(
                    'value'       => 'PT',
                    'label'       => esc_html__('Portugal', 'gocourier'),
                  ),
                  array(
                    'value'       => 'PR',
                    'label'       => esc_html__('Puerto Rico', 'gocourier'),
                  ),
				  array(
                    'value'       => 'QA',
                    'label'       => esc_html__('Qatar', 'gocourier'),
                  ),
				  array(
                    'value'       => 'RO',
                    'label'       => esc_html__('Romania', 'gocourier'),
                  ),
				  array(
                    'value'       => 'RU',
                    'label'       => esc_html__('Russian Federation', 'gocourier'),
                  ),
                  array(
                    'value'       => 'RW',
                    'label'       => esc_html__('Rwanda', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SH',
                    'label'       => esc_html__('Saint Helena Ascension & Tristan da Cunha', 'gocourier'),
                  ),
				  array(
                    'value'       => 'KN',
                    'label'       => esc_html__('Saint Kitts & Nevis', 'gocourier'),
                  ),
                  array(
                    'value'       => 'LC',
                    'label'       => esc_html__('Saint Lucia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'MF',
                    'label'       => esc_html__('Saint Martin (French part)', 'gocourier'),
                  ),
				  array(
                    'value'       => 'PM',
                    'label'       => esc_html__('Saint Pierre and Miquelon', 'gocourier'),
                  ),
				  array(
                    'value'       => 'VC',
                    'label'       => esc_html__('Saint Vincent and the Grenadines', 'gocourier'),
                  ),
                  array(
                    'value'       => 'WS',
                    'label'       => esc_html__('Samoa', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SM',
                    'label'       => esc_html__('San Marino', 'gocourier'),
                  ),
				  array(
                    'value'       => 'ST',
                    'label'       => esc_html__('Sao Tome and Principe', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SA',
                    'label'       => esc_html__('Saudi Arabia', 'gocourier'),
                  ),
                  array(
                    'value'       => 'SN',
                    'label'       => esc_html__('Senegal', 'gocourier'),
                  ),
				  array(
                    'value'       => 'RS',
                    'label'       => esc_html__('Serbia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SC',
                    'label'       => esc_html__('Seychelles', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SL',
                    'label'       => esc_html__('Sierra Leone', 'gocourier'),
                  ),
                  array(
                    'value'       => 'SG',
                    'label'       => esc_html__('Singapore', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SX',
                    'label'       => esc_html__('Sint Maarten (Dutch part)', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SK',
                    'label'       => esc_html__('Slovakia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SI',
                    'label'       => esc_html__('Slovenia', 'gocourier'),
                  ),
                  array(
                    'value'       => 'SB',
                    'label'       => esc_html__('Solomon Islands', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SO',
                    'label'       => esc_html__('Somalia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'ZA',
                    'label'       => esc_html__('South Africa', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GS',
                    'label'       => esc_html__('South Georgia and the South Sandwich Islands', 'gocourier'),
                  ),
                  array(
                    'value'       => 'SS',
                    'label'       => esc_html__('South Sudan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'ES',
                    'label'       => esc_html__('Spain', 'gocourier'),
                  ),
				  array(
                    'value'       => 'LK',
                    'label'       => esc_html__('Sri Lanka', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SD',
                    'label'       => esc_html__('Sudan', 'gocourier'),
                  ),
                  array(
                    'value'       => 'SR',
                    'label'       => esc_html__('Suriname', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SJ',
                    'label'       => esc_html__('Svalbard and Jan Mayen', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SZ',
                    'label'       => esc_html__('Swaziland', 'gocourier'),
                  ),
				  array(
                    'value'       => 'SY',
                    'label'       => esc_html__('Syrian Arab Republic', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TW',
                    'label'       => esc_html__('Taiwan, Province of China', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TJ',
                    'label'       => esc_html__('Tajikistan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TZ',
                    'label'       => esc_html__('Tanzania, United Republic of', 'gocourier'),
                  ),
                  array(
                    'value'       => 'TH',
                    'label'       => esc_html__('Thailand', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TL',
                    'label'       => esc_html__('Timor-Leste', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TG',
                    'label'       => esc_html__('Togo', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TK',
                    'label'       => esc_html__('Tokelau', 'gocourier'),
                  ),
                  array(
                    'value'       => 'TO',
                    'label'       => esc_html__('Tonga', 'gocourier'),

                  ),
				  array(
                    'value'       => 'TT',
                    'label'       => esc_html__('Trinidad and Tobago', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TN',
                    'label'       => esc_html__('Tunisia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TR',
                    'label'       => esc_html__('Turkey', 'gocourier'),
                  ),
                  array(
                    'value'       => 'TM',
                    'label'       => esc_html__('Turkmenistan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TC',
                    'label'       => esc_html__('Turks and Caicos Islands', 'gocourier'),
                  ),
				  array(
                    'value'       => 'TV',
                    'label'       => esc_html__('Tuvalu', 'gocourier'),
                  ),
				  array(
                    'value'       => 'UG',
                    'label'       => esc_html__('Uganda', 'gocourier'),
                  ),
                  array(
                    'value'       => 'UA',
                    'label'       => esc_html__('Ukraine', 'gocourier'),
                  ),
				  array(
                    'value'       => 'AE',
                    'label'       => esc_html__('United Arab Emirates', 'gocourier'),
                  ),
				  array(
                    'value'       => 'GB',
                    'label'       => esc_html__('United Kingdom', 'gocourier'),
                  ),
				  array(
                    'value'       => 'US',
                    'label'       => esc_html__('United States', 'gocourier'),
                  ),
                  array(
                    'value'       => 'UM',
                    'label'       => esc_html__('United States Minor Outlying Islands', 'gocourier'),
                  ),
				  array(
                    'value'       => 'UY',
                    'label'       => esc_html__('Uruguay', 'gocourier'),
                  ),
				  array(
                    'value'       => 'UZ',
                    'label'       => esc_html__('Uzbekistan', 'gocourier'),
                  ),
				  array(
                    'value'       => 'VU',
                    'label'       => esc_html__('Vanuatu', 'gocourier'),
                  ),
                  array(
                    'value'       => 'VE',
                    'label'       => esc_html__('Venezuela, Bolivarian Republic of', 'gocourier'),
                  ),
				  array(
                    'value'       => 'VN',
                    'label'       => esc_html__('Viet Nam', 'gocourier'),
                  ),
				  array(
                    'value'       => 'VG',
                    'label'       => esc_html__('Virgin Islands, British', 'gocourier'),
                  ),
				  array(
                    'value'       => 'VI',
                    'label'       => esc_html__('Virgin Islands, U.S.', 'gocourier'),
                  ),
				  array(
                    'value'       => 'WF',
                    'label'       => esc_html__('Wallis and Futuna', 'gocourier'),
                  ),
				  array(
                    'value'       => 'EH',
                    'label'       => esc_html__('Western Sahara', 'gocourier'),
                  ),
                  array(
                    'value'       => 'YE',
                    'label'       => esc_html__('Yemen', 'gocourier'),
                  ),
				  array(
                    'value'       => 'ZM',
                    'label'       => esc_html__('Zambia', 'gocourier'),
                  ),
				  array(
                    'value'       => 'ZW',
                    'label'       => esc_html__('Zimbabwe', 'gocourier'),
                  ),
              ),
          ),
		  array(
            'id'          => 'min_weight',
            'label'       => esc_html__('Item Min Weight', 'gocourier'),
            'desc'        => esc_html__('Item min weight', 'gocourier'),
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and',
            'choices'     => '',
          ),
            array(
            'id'          => 'max_weight',
            'label'       => esc_html__('Item Max Weight', 'gocourier'),
            'desc'        => esc_html__('Item max weight', 'gocourier'),
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and',
            'choices'     => '',
          ),
		  array(
            'id'          => 'item_price',
            'label'       => esc_html__('Item Price', 'gocourier'),
            'desc'        => esc_html__('Price Should be integer value(and currency will be woocommerce currency)', 'gocourier'),
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and',
            'choices'     => '',
          ),
		  array(
			'id'          => 'select_product_to_connect',
			'label'       => esc_html__( 'Select Product to Connect', 'gocourier' ),
			'desc'        => esc_html__( 'All products will show here', 'gocourier' ),
			'type'        => 'custom-post-type-select',
			'post_type'   => 'product',
		),
		
          ),
      ),		
    );

	return apply_filters( 'gocourier_calculate_cost_options', $options );
}  
?>