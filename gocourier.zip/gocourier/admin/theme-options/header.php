<?php
function gocourier_header_options( $options = array() ){
  $options = array(
    array(
      'id'          => 'search_icon_in_menu',
      'label'       => esc_html__( 'Display Search Icon in Header Menu', 'gocourier' ),
      'desc'        => '',
      'std'         => 'on',
      'type'        => 'on-off',
      'section'     => 'header_options',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'min_max_step'=> '',
      'class'       => '',
      'condition'   => '',
      'operator'    => 'and'
    ),
    array(
      'id'          => 'show_signin_option_in_header',
      'label'       => esc_html__( 'Display Login Option in Header', 'gocourier' ),
      'desc'        => '',
      'std'         => 'on',
      'type'        => 'on-off',
      'section'     => 'header_options',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'min_max_step'=> '',
      'class'       => '',
      'condition'   => '',
      'operator'    => 'and'
    ),
    array(
      'id'          => 'sticky_menu_header',
      'label'       => esc_html__( 'Sticky Menu', 'gocourier' ),
      'desc'        => '',
      'std'         => 'on',
      'type'        => 'on-off',
      'section'     => 'header_options',
      'rows'        => '',
      'post_type'   => '',
      'taxonomy'    => '',
      'min_max_step'=> '',
      'class'       => '',
      'condition'   => '',
      'operator'    => 'and'
    )
  );
  return apply_filters( 'gocourier_header_options', $options );
} 
?>