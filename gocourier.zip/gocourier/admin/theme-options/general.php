<?php
function gocourier_general_options( $options = array() ){
	
	$options = array(
	  array(
        'id'          => 'main_logo',
        'label'       => esc_html__( 'Header Logo', 'gocourier' ),
        'desc'        => esc_html__( 'Header logo', 'gocourier' ),
        'std'         => GOCOURIERTHEMEURI. 'images/logo.png',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'main_logo_alter',
        'label'       => esc_html__( 'Header Logo Alter', 'gocourier' ),
        'desc'        => esc_html__( 'Header logo alter', 'gocourier' ),
        'std'         => GOCOURIERTHEMEURI. 'images/logo-2.png',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'admin_logo',
        'label'       => esc_html__( 'Admin Logo', 'gocourier' ),
        'desc'        => esc_html__( 'Admin login logo', 'gocourier' ),
        'std'         => GOCOURIERTHEMEURI. 'images/logo.png',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'header_top_contact_info',
        'label'       => esc_html__( 'Header Top Info', 'gocourier' ),
        'desc'        => esc_html__( 'Header top contact info', 'gocourier' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	  array(
        'id'          => 'preloader_show',
        'label'       => esc_html__( 'Show Preloader', 'gocourier' ),
        'desc'        => '',
        'std'         => 'on',
        'type'        => 'on-off',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
	);

	return apply_filters( 'gocourier_general_options', $options );
}
?>