<?php
function gocourier_styling_options( $options = array() ){
	$options = array(
		array(
        'id'          => 'preset_color',
        'label'       => esc_html__( 'Preset Color', 'gocourier' ),
        'desc'        => esc_html__( 'Main preset color', 'gocourier' ),
        'std'         => '#f6ab36',
        'type'        => 'colorpicker',
        'section'     => 'styling_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'      => array(
                array(
                	'selector' => '.top-header-info a,.featured-on .pricing-box,.pricing-header h3,#owl-testimonial .owl-nav [class*="owl-"]:hover, .ts-form-calculate .button.form-control,.ts-box:before,.style_2 .featured-on .pricing-footer a,.wpcf7-form-control.wpcf7-submit,.more-link,.pagination > li > a:hover, .pagination > li > span:hover, .pagination > li > a:focus, .pagination > li > span:focus,.btn-default:hover,.btn-default:focus,.btn-white:hover,.btn-white:focus,.user-login-content .button.form-control,.sign-in-details:after,.home .product-tracking-form:before,.about-wrap:before,.pagination > li.current > a',
                	'property'   => 'background-color'
                ),
                array(
                	'selector' => 'a:hover, .top-header-info p span,.header-top-menu li a:hover, .copyright-text i,.footer-widget ul li a:hover, .pricing-footer a,.searchmenu a i,.navbar-default .nav > li > a:hover,.woocommerce .woocommerce-info::before,.slim-wrap ul.menu-items li a:hover,.navbar-default .navbar-right ul li a:hover,.header-main.style_2 .navbar-default .nav > li > a:hover',
                	'property'   => 'color'
                ),
                array(
                    'selector' => '.testi-item img.img-circle,.searchmenu a i,.form-control:focus,.form-control:focus:not([readonly]),.style_2 .featured-on .pricing-box,.style_2 .featured-on .pricing-footer a,.shop-buttons .btn-white:hover',
                    'property'   => 'border-color'
                ),
                array(
                    'selector' => 'blockquote,pre',
                    'property'   => 'border-left-color'
                ),
                array(
                    'selector' => '.woocommerce .woocommerce-message,.woocommerce .woocommerce-info',
                    'property' => 'border-top-color',
                ),
                array(
                    'selector' => '',
                    'property' => 'border-right-color',
                ),
                array(
                    'selector' => '',
                    'property' => 'border-bottom-color',
                ),
				array(
                    'selector' => '',
                    'property'   => 'border-color',
					'opacity'	=> 0.7,
                ),
				array(
                'selector' => '',
                'property'   => 'background-color',
				'opacity'	=> 0.8,
                ),
            )
      ),
    );

	return apply_filters( 'gocourier_styling_options', $options );
}  
?>