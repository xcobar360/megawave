<?php
function gocourier_background_options( $options = array() ){
	$options = array(
		array(
        'id'          => 'container_width',
        'label'       => esc_html__( 'Container width', 'gocourier' ),
        'desc'        => esc_html__( 'Main container width', 'gocourier' ),
        'std'         => array(1170, 'px'),
        'type'        => 'measurement',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'      =>array(
                array(
                    'selector' => '.container',
                    'property' => 'max-width'
                    )
            )
      ),
      array(
        'id'          => 'body_background',
        'label'       => esc_html__( 'Body background', 'gocourier' ),
        'desc'        => esc_html__( 'Background can be image or color', 'gocourier' ),
        'std'         => array(),
        'type'        => 'background',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'   => array(
                array(
                    'selector' => 'body'
                    )
            )
      ),
      array(
        'id'          => 'main_container_background',
        'label'       => esc_html__( 'Main container background', 'gocourier' ),
        'desc'        => esc_html__( 'Background can be image or color', 'gocourier' ),
        'std'         => array(),
        'type'        => 'background',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'   => array(
                array(
                    'selector' => '.container'
                    )
            )
      ),
    array(
        'id'          => 'sidebar_background',
        'label'       => esc_html__( 'Sidebar background', 'gocourier' ),
        'desc'        => esc_html__( 'Sidebar Background', 'gocourier' ),
        'std'         => array('background-image' => '', 'background-color' => '#fff'),
        'type'        => 'background',
        'section'     => 'background_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'action'   => array(
                array(
                    'selector' => '.sidebar'
                    )
            )
      ),     
    );

	return apply_filters( 'gocourier_background_options', $options );
}  
?>