<?php
/**
 * Order details
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/order/order-details.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you (the theme developer).
 * will need to copy the new files to your theme to maintain compatibility. We try to do this.
 * as little as possible, but it does happen. When this occurs the version of the template file will.
 * be bumped and the readme will list any important changes.
 *
 * @see 	    http://docs.woothemes.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 4.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! $order = wc_get_order( $order_id ) ) {
	return;
}

$order_items           = $order->get_items( apply_filters( 'woocommerce_purchase_order_item_types', 'line_item' ) );
$show_purchase_note    = $order->has_status( apply_filters( 'woocommerce_purchase_note_order_statuses', array( 'completed', 'processing' ) ) );
$show_customer_details = is_user_logged_in() && $order->get_user_id() === get_current_user_id();
$downloads             = $order->get_downloadable_items();
$show_downloads        = $order->has_downloadable_item() && $order->is_download_permitted();

if ( $show_downloads ) {
	wc_get_template(
		'order/order-downloads.php',
		array(
			'downloads'  => $downloads,
			'show_title' => true,
		)
	);
}
?>
<?php
	foreach ( $order_items as $item_id => $item ) {
		$product = apply_filters( 'woocommerce_order_item_product', $item->get_product(), $item );

		wc_get_template( 'order/order-details-item.php', array(
			'order'			     => $order,
			'item_id'		     => $item_id,
			'item'			     => $item,
			'show_purchase_note' => $show_purchase_note,
			'purchase_note'	     => $product ? $product->get_purchase_note() : '',
			'product'	         => $product,
		) );
?>
<?php do_action( 'woocommerce_order_items_table', $order ); ?>

<div class="row order-content-main">
<div class="col-md-7">
	<?php echo get_the_post_thumbnail($product->get_id()); ?>
</div>
<div class="col-md-5">

	<div class="item-details-order row">
    	<div class="right-details-background">
    	<div class="item-des-order-wrapper"><div class="col-md-5 item-des-order order-left"><?php esc_html_e('Product Name: ','gocourier'); ?></div>
        <div class="col-md-7 item-des-order order-right"><?php echo get_the_title($product->get_id()); ?></div>
        </div>
        <div class="item-des-order-wrapper">
        <div class="col-md-5 item-des-order order-left"><?php esc_html_e('Product ID: ','gocourier'); ?></div>
        <div class="col-md-7 item-des-order order-right"><?php echo esc_html($product->get_id()); ?></div>
        </div>
        <div class="item-des-order-wrapper">
        <div class="col-md-5 item-des-order order-left"><?php esc_html_e('Order Date: ','gocourier'); ?></div>
        <div class="col-md-7 item-des-order order-right"><?php echo date_i18n( __( 'l jS \o\f F Y', 'gocourier' ), strtotime( $order->get_date_created() ) ); ?></div>
        </div>
        <div class="item-des-order-wrapper">
        <div class="col-md-5 item-des-order order-left"><?php esc_html_e('Order Status: ','gocourier'); ?></div>
        <div class="col-md-7 item-des-order order-right"><?php echo esc_html($order->get_status()); ?></div>
        </div>
        <div class="item-des-order-wrapper">
        <div class="col-md-5 item-des-order order-left"><?php esc_html_e('Pick Up Date: ','gocourier'); ?></div>
        <div class="col-md-7 item-des-order order-right"><?php echo date_i18n( __( 'l jS \o\f F Y', 'gocourier' ), strtotime( $order->get_date_completed() ) ); ?></div>
        </div>
        <div class="item-des-order-wrapper">
        <div class="col-md-5 item-des-order order-left"><?php esc_html_e('Total Price: ','gocourier'); ?></div>
        <div class="col-md-7 item-des-order order-right"><?php echo wp_kses($order->get_formatted_line_subtotal( $item ), array('div'=>array('class'=>array(), 'span'=>array()))); ?></div>
        </div>
        </div>
    </div>


</div>
</div>

<?php } ?>

<div class="shop_table_details order_details">
	<?php do_action( 'woocommerce_order_items_table', $order ); ?>	
	<?php
    foreach ( $order->get_order_item_totals() as $key => $total ) {
        ?>

        <?php echo esc_html($total['label']); ?>
        <?php echo wp_kses($total['value'], array('div'=>array('class'=>array(), 'span'=>array()))); ?>
        <?php
    }
    ?>
</div>

<?php
if ( $show_customer_details ) {
	wc_get_template( 'order/order-details-customer.php', array( 'order' => $order ) );
}