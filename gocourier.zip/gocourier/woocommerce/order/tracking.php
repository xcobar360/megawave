<?php
/**
 * Order tracking
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/order/tracking.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you (the theme developer).
 * will need to copy the new files to your theme to maintain compatibility. We try to do this.
 * as little as possible, but it does happen. When this occurs the version of the template file will.
 * be bumped and the readme will list any important changes.
 *
 * @see 	    http://docs.woothemes.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 2.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$order_status_text = sprintf( wp_kses(__( 'Order #%s which was made %s has the status &ldquo;%s&rdquo;', 'gocourier' ), array('span'=>array('class'=>array()), 'time'=>array())), $order->get_order_number(), human_time_diff( strtotime( $order->get_date_created() ), current_time( 'timestamp' ) ) . ' ' . esc_html__( 'ago', 'gocourier' ), wc_get_order_status_name( $order->get_status() ) );

if ( $order->has_status( 'completed' ) ) $order_status_text .= ' ' . esc_html__( 'and was completed', 'gocourier' ) . ' ' . human_time_diff( strtotime( $order->get_date_completed() ), current_time( 'timestamp' ) ) . esc_html__( ' ago', 'gocourier' );

$order_status_text .= '.';

echo wpautop( esc_attr( apply_filters( 'woocommerce_order_tracking_status', $order_status_text, $order ) ) );


if ( $notes = $order->get_customer_order_notes() ) : ?>
	<h2><?php esc_html_e( 'Order Updates', 'gocourier' ); ?></h2>
	<table class="commentlist notes">
    	<tr>
        	<th><?php esc_html_e( 'Number', 'gocourier' ); ?></th>
            <th><?php esc_html_e( 'Date', 'gocourier' ); ?></th>
            <th><?php esc_html_e( 'Comment', 'gocourier' ); ?></th>
        </tr>
        <?php $i = 1; ?>
		<?php foreach ( $notes as $note ) : ?>
        <tr>
        	<td><?php echo esc_html($i); ?></td>
            <td><?php echo date_i18n( __( 'l jS \o\f F Y, h:ia', 'gocourier' ), strtotime( $note->comment_date ) ); ?></td>
            <td><?php echo wpautop( wptexturize( wp_kses_post( $note->comment_content ) ) ); ?></td>
        </tr>
		
        <?php $i++; ?>
		<?php endforeach; ?>
	</table>
<?php endif; ?>

<?php do_action( 'woocommerce_view_order', $order->get_id() ); ?>
