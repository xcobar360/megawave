<?php
/**
 * Loop Price
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $product;
?>

<?php if ( $price_html = $product->get_price_html() ) : ?>
	<span><?php echo wp_kses($price_html, array('div'=>array('class'=>array()), 'span'=>array('class'=>array()), 'p'=>array('class'=>array()), 'del'=>array(), 'ins'=>array())); ?></span>
<?php endif; ?>
