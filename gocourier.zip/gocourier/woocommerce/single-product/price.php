<?php
/**
 * Single Product Price, including microdata for SEO
 *
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 3.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $post, $product;

$cat_count = sizeof( get_the_terms( $post->ID, 'product_cat' ) );

?>
<div class="meta">

	<?php echo wp_kses($product->get_categories( ', ', '<span>' . _n( 'In: ', 'In: ', $cat_count, 'gocourier' ) . ' ', '</span>' ), array('ul'=>array('class'=>array()), 'li'=>array('class'=>array()), 'a'=>array('class'=>array()), 'span'=>array('class'=>array()))); ?>
    
    <span><?php echo wp_kses($product->get_price_html(), array('span'=>array('class'=>array()), 'del'=>array(), 'ins'=>array())); ?></span>


</div>
