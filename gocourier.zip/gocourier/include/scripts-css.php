<?php
/**
 * Enqueue scripts and styles for the front end.
 *
 */
function gocourier_scripts() {
	// Add Lato font, used in the main stylesheet.
	$fonts_url = gocourier_fonts_url();
	if ( ! empty( $fonts_url ) ){
		wp_enqueue_style( 'gocourier-fonts', esc_url_raw( $fonts_url ), array(), null );
	}
	wp_enqueue_style( 'bootstrap', GOCOURIERTHEMEURI . 'css/bootstrap.css', array(), null );
	wp_enqueue_style( 'fontawesome', GOCOURIERTHEMEURI . 'css/font-awesome.min.css', array(), null );	
	wp_enqueue_style( 'gocourier-et-line', GOCOURIERTHEMEURI . 'css/et-line.css', array(), null );
	wp_enqueue_style( 'carousel', GOCOURIERTHEMEURI . 'css/carousel.css', array(), null );
	wp_enqueue_style( 'animate', GOCOURIERTHEMEURI . 'css/animate.css', array(), null );
	wp_enqueue_style( 'slimmenu', GOCOURIERTHEMEURI . 'css/slimmenu.css', array(), null );
	wp_enqueue_style( 'gocourier-styles', GOCOURIERTHEMEURI . 'css/styles.css', array(), null );

	// Load our main stylesheet.
	wp_enqueue_style( 'gocourier-style', get_stylesheet_uri() );
	wp_enqueue_style( 'gocourier-responsive', GOCOURIERTHEMEURI . 'css/responsive.css', array( 'gocourier-style' ), null );


	//scripts
	/*
	 * Adds JavaScript to pages with the comment form to support
	 * sites with threaded comments (when in use).
	 */
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ){
		wp_enqueue_script( 'comment-reply' );
	}
	// Adds JavaScript.
	wp_enqueue_script( 'bootstrap', GOCOURIERTHEMEURI . 'js/bootstrap.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'gocourier-wow', GOCOURIERTHEMEURI . 'js/wow.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'scroll', GOCOURIERTHEMEURI . '/js/scroll.js', array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'waypoints', GOCOURIERTHEMEURI . 'js/waypoints.min.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'carousel', GOCOURIERTHEMEURI . '/js/carousel.js', array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'jquery.easing.min', GOCOURIERTHEMEURI . 'js/lib/jquery.easing.min.js', array( 'jquery' ), '1.0', true );
	wp_enqueue_script( 'fitvid', GOCOURIERTHEMEURI . 'js/jquery.fitvid.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'jquery.sticky', GOCOURIERTHEMEURI . 'js/jquery.sticky.js', array( 'jquery' ), '', true );
	wp_enqueue_script( 'jquery.slimmenu.min', GOCOURIERTHEMEURI . '/js/jquery.slimmenu.min.js', array( 'jquery' ), '1.0', true );		
	wp_enqueue_script( 'gocourier-scripts', GOCOURIERTHEMEURI . 'js/scripts.js', array( 'jquery' ), '', true );	
	wp_enqueue_script( 'gocourier-custom', GOCOURIERTHEMEURI . 'js/custom.js', array( 'jquery' ), '', true );
	
	wp_localize_script( 'gocourier-scripts', 'gocourier', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ),'GOCOURIERTHEMEURI' => GOCOURIERTHEMEURI));
	
	
}
add_action( 'wp_enqueue_scripts', 'gocourier_scripts' );

function gocourier_styles_custom_banner() {
	wp_enqueue_style('gocourier-custom-banner-style', GOCOURIERTHEMEURI . 'css/custom_style_banner.css');
	$custom_css = '';
	$banner_image = '';
	if(is_page()){
		$banner_image = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );
	} elseif(is_singular('post')) {
		$banner_image = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );
	} else {
		$banner_image = (function_exists('ot_get_option'))? ot_get_option( 'blog_banner', '' ) : '';
	}
	
	if(class_exists( 'woocommerce' )){
		if(is_woocommerce()){
			$banner_image = (function_exists('ot_get_option'))? ot_get_option( 'shop_archive_banner', '' ) : '';
		}
		if(is_product()){
			$banner_image = wp_get_attachment_url( get_post_thumbnail_id(get_the_ID()) );
		}
	}
	if($banner_image != ''){
    $custom_css .= ".page-section {
        background: url(".esc_url($banner_image).");
		background-size: cover;
		background-position: 50% center;
    }
	.grey {
		background: rgba(255, 255, 255, 0.5);
	}
	";    
    }
	$custom_css .= gocourier_custom_css_from_theme_options();
    wp_add_inline_style( 'gocourier-custom-banner-style', $custom_css );
}
add_action( 'wp_enqueue_scripts', 'gocourier_styles_custom_banner' );
?>