<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if(defined('ELEMENTOR_VERSION')):

class GoCourier_Elementor_Widgets_Init{
	
    public static $instance;

	/**
     * Load Construct
     * 
     * @since 1.0
     */
	/** GoCourier Class Constructor **/
	public function __construct(){
		add_action('elementor/init', array($this, 'gocourier_elementor_category'));
        add_action('elementor/widgets/register', array($this, 'gocourier_all_elements'));
		add_action('elementor/frontend/after_enqueue_scripts', array( $this, 'gocourier_enqueue_scripts' ) );        
	}
	
	public static function get_instance(){
		if (null === self::$instance) {
			self::$instance = new self();
		}
		return self::$instance;
	}

    /** Enqueue Scripts and Stylesheets **/ 
    
     public function gocourier_enqueue_scripts() {
		 wp_enqueue_script( 'gocourier-elementor', GOCOURIERTHEMEURI . 'js/scripts-elementor.js', [ 'jquery' ], false, true );
    }
	
	/** Elementor add category **/

    public function gocourier_elementor_category(){    
		\Elementor\Plugin::$instance->elements_manager->add_category(
			'gocourier-all-elements',
			[
				'title' =>esc_html__( 'GoCourier', 'gocourier' ),
				'icon' => 'fas fa-hand-holding-usd',
			],
			1
		);
    }

    public function gocourier_all_elements($elements){

      require_once GOCOURIERTHEMEDIR .'include/elements/title.php';
      $elements->register(new Elementor\GoCourier_Title());
	  
	  require_once GOCOURIERTHEMEDIR .'include/elements/services.php';
      $elements->register(new Elementor\GoCourier_Services());
	  
	  require_once GOCOURIERTHEMEDIR .'include/elements/testmonials.php';
      $elements->register(new Elementor\GoCourier_Testmonials());
	  
	  require_once GOCOURIERTHEMEDIR .'include/elements/pricing.php';
      $elements->register(new Elementor\GoCourier_Pricing());
	  
	  require_once GOCOURIERTHEMEDIR .'include/elements/contact-box.php';
      $elements->register(new Elementor\GoCourier_Contact_Box());
	  
	  require_once GOCOURIERTHEMEDIR .'include/elements/feature-lists.php';
      $elements->register(new Elementor\GoCourier_Feature_Lists());
	  
	  require_once GOCOURIERTHEMEDIR .'include/elements/percent-box.php';
      $elements->register(new Elementor\GoCourier_Percent_Box());
	  
    }

}

if (class_exists('GoCourier_Elementor_Widgets_Init')){
	GoCourier_Elementor_Widgets_Init::get_instance();
}

endif;