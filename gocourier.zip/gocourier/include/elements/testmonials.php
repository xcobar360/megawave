<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class GoCourier_Testmonials extends Widget_Base {


  public $base;

    public function get_name() {
        return 'gocourier-testmonials';
    }

    public function get_title() {

        return esc_html__( 'Testmonials', 'gocourier'  );

    }

    public function get_icon() { 
        return 'fas fa-comments';
    }

    public function get_categories() {
        return [ 'gocourier-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
		
		$this->add_control(
			'testi_style',
			[
				'label' => esc_html__( 'Style', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'gocourier' ),
					'style2' => esc_html__( 'Style 2', 'gocourier' ),
				],
			]
		);
		
		$repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
			'testmonials_description',
			[
				'label' => esc_html__( 'Description', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => esc_html__( "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.", 'gocourier' ),
				'placeholder' => esc_html__( 'Type your description here', 'gocourier' ),
			]
        );

        $repeater->add_control(
			'testmonials_image',
			[
				'label' => esc_html__( 'Author Image', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
        );
        
        $repeater->add_control(
			'author_name',
			[
				'label' => esc_html__( 'Author Name', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Rosalina D. William', 'gocourier' ),
				'placeholder' => esc_html__( 'Type your title here', 'gocourier' ),
			]
        );

        $repeater->add_control(
			'author_designation',
			[
				'label' => esc_html__( 'Author Designation', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => '',
				'placeholder' => esc_html__( 'Type your designation', 'gocourier' ),
			]
        );

        $repeater->add_control(
			'author_icon',
			[
				'label' => esc_html__( 'Author Icon', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-quote-left',
					'library' => 'solid',
				],
			]
		);
		
		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Testominials List', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'testmonials_description' => esc_html__( "It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English.", 'gocourier' ),
						'testmonials_image' => esc_html__( 'Author Image', 'gocourier' ),
						'author_name' => esc_html__( 'Rosalina D. William', 'gocourier' ),
						'author_designation' => '',
						'author_icon' => esc_html__( 'Author Icon', 'gocourier' ),
					],
				],
				'title_field' => '{{{ author_name }}}',
			]
		);
        
        $this->add_responsive_control(
            'text_align', [
                'label'          => esc_html__( 'Alignment', 'gocourier'  ),
                'type'           => Controls_Manager::CHOOSE,
                'options'        => [
    
                    'left'         => [
                        'title'    => esc_html__( 'Left', 'gocourier'  ),
                        'icon'     => 'fas fa-align-left',
                    ],
                    'center'     => [
                        'title'    => esc_html__( 'Center', 'gocourier'  ),
                        'icon'     => 'fas fa-align-center',
                    ],
                    'right'         => [
                        'title'     => esc_html__( 'Right', 'gocourier'  ),
                        'icon'     => 'fas fa-align-right',
                    ],
                ],
               'default'         => 'center',
               'selectors' => [
                   '{{WRAPPER}} .testimonials-content' => 'text-align: {{VALUE}};'
               ],
            ]
        );
 

        $this->add_responsive_control(
			'padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .testimonials-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  $this->start_controls_section(
			'control_tab_section',
			[
				'label' => esc_html__( 'Controls', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
		
		$this->add_control(
			'number_of_items',
			[
				'label' => esc_html__( 'Number of Items', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 3,
				'step' => 1,
				'default' => 1,
			]
		);
		
		$this->add_control(
			'show_dots',
			[
				'label' => esc_html__( 'Show Dots', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'gocourier' ),
				'label_off' => esc_html__( 'Hide', 'gocourier' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);
		
		$this->add_control(
			'show_navs',
			[
				'label' => esc_html__( 'Show Navs', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'gocourier' ),
				'label_off' => esc_html__( 'Hide', 'gocourier' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->end_controls_section();
	  
	  // Style Section //
		
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Name', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'title_tabs'
		);
		
		$this->start_controls_tab(
			'title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testi-item h4' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .quote-img i' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'icon_bg_color',
			[
				'label' => esc_html__( 'Icon BG Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .quote-img' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'title_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'title_color_hover',
			[
				'label' => esc_html__( 'Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testi-item:hover .testi-item h4' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'icon_hover_color',
			[
				'label' => esc_html__( 'Icon Hover Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testi-item:hover .quote-img i' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'icon_hover_bg_color',
			[
				'label' => esc_html__( 'Icon Hover BG Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testi-item:hover .quote-img' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .testi-item h4',
			]
		);		

        $this->add_responsive_control(
			'title_padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .testi-item h4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  $this->start_controls_section(
			'style_bg_section',
			[
				'label' => esc_html__( 'Description', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'bgtitle_tabs'
		);
		
		$this->start_controls_tab(
			'bgtitle_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'bgtitle_color',
			[
				'label' => esc_html__( 'Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testi-item .lead' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'bgtitle_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'bgtitle_color_hover',
			[
				'label' => esc_html__( 'Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testi-item:hover .lead' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bg_title_typography',
				'label' => esc_html__( 'Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .testi-item .lead',
			]
		);
		
		$this->add_control(
			'bg_border_color',
			[
				'label' => esc_html__( 'Image Border Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testi-mem-img img' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_responsive_control(
			'image_border_radius',
			[
				'label' =>esc_html__( 'Image Border Radius', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .testi-mem-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
		
		$this->add_control(
			'desigination_color',
			[
				'label' => esc_html__( 'Desigination Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testi-item .testi-desigination' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_responsive_control(
			'bg_title_padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .testi-item .lead' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
	  $this->end_controls_section();
	  
	  $this->start_controls_section(
			'style_control_section',
			[
				'label' => esc_html__( 'Controls', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'bgcontrol_tabs'
		);
		
		$this->start_controls_tab(
			'bgcontrol_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'bgcontrol_color',
			[
				'label' => esc_html__( 'Dots Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owl-theme .owl-dots .owl-dot span' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'bgcontrol_nav_color',
			[
				'label' => esc_html__( 'Nav BG Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonials-content.owl-theme .owl-nav [class*="owl-"]' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'bgcontrol_nav_text_color',
			[
				'label' => esc_html__( 'Nav Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonials-content.owl-theme .owl-nav [class*="owl-"]' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'bgcontrol_hover_tab',
			[
				'label' => esc_html__( 'Active', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'bgcontrol_color_hover',
			[
				'label' => esc_html__( 'Dots Active Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owl-theme .owl-dots .owl-dot.active span, {{WRAPPER}} .owl-theme .owl-dots .owl-dot:hover span' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'bgcontrol_nav_color_hover',
			[
				'label' => esc_html__( 'Nav BG Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonials-content.owl-theme .owl-nav [class*="owl-"]:hover' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'bgcontrol_nav_text_color_hover',
			[
				'label' => esc_html__( 'Nav Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonials-content.owl-theme .owl-nav [class*="owl-"]:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_responsive_control(
			'nav_position',
			[
				'label' =>esc_html__( 'Nav Position', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .testimonials-content.owl-theme .owl-controls' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
	  $this->end_controls_section();
	  
	  // End Style Section //
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
		
        if ( $settings['list'] ):
		$show_dots = $settings['show_dots'];
		if($show_dots == 'yes'){
			$show_dots = 'true';
		} else {
			$show_dots = 'false';
		}
		
		$show_navs = $settings['show_navs'];
		if($show_navs == 'yes'){
			$show_navs = 'true';
		} else {
			$show_navs = 'false';
		}
		
		if($settings['testi_style'] == 'style2'){
			$animateout = 'fadeOut';
			$data_tablet = '1';
		} else {
			$animateout = 'false';
			$data_tablet = '1';
		}
		
		?>
        <div class="testimonials-content testi-carousel owl-carousel" data-items-tablet="<?php echo esc_attr($data_tablet); ?>" data-items="<?php echo esc_attr($settings['number_of_items']); ?>" data-nav="<?php echo esc_attr($show_navs); ?>" data-dots="<?php echo esc_attr($show_dots); ?>" data-margin="30" data-autoplay="true" data-animateout="<?php echo esc_attr($animateout); ?>">           
        	<?php			
			foreach (  $settings['list'] as $item ):
			?>
                <div class="item testi-<?php echo esc_attr($settings['testi_style']); ?>">
                	<?php if($settings['testi_style'] == 'style2'): ?>
                    
					<?php else: ?>
                    <div class="testi-item">
                    	<?php if($item['testmonials_image']['url'] != ''): ?>
                        	<div class="testi-mem-img"><img src="<?php echo esc_html($item['testmonials_image']['url']); ?>" alt="<?php echo esc_attr($item['author_name']); ?>" class="img-circle" /><div class="quote-img"><?php \Elementor\Icons_Manager::render_icon( $item['author_icon'], [ 'aria-hidden' => 'true' ] ); ?></div></div>
                        <?php endif; ?>
                        
                        <?php if($item['testmonials_description'] != ''): ?>
                            <p class="lead"><?php echo esc_html($item['testmonials_description']); ?></p>
                            <?php endif; ?>
                        <h4><?php echo esc_html($item['author_name']); ?></h4>
                        <?php if($item['author_designation'] != ''): ?>
                        <p class="testi-desigination"><?php echo esc_html($item['author_designation']); ?></p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>  
        </div>
        <?php endif; ?>

        <?php
	}

    protected function content_template() {}
}