<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class GoCourier_Services extends Widget_Base {


  public $base;

    public function get_name() {
        return 'gocourier-services';
    }

    public function get_title() {

        return esc_html__( 'Services', 'gocourier'  );

    }

    public function get_icon() { 
        return 'fas fa-grip-horizontal';
    }

    public function get_categories() {
        return [ 'gocourier-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
		
		$this->add_control(
			'posts_style',
			[
				'label' => esc_html__( 'Style', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'gocourier' ),
					'style2' => esc_html__( 'Style 2', 'gocourier' ),
				],
			]
		);
		
		$this->add_control(
			'number',
			[
				'label' => esc_html__( 'Number', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '1.', 'gocourier' ),
				'placeholder' => esc_html__( 'Type your number', 'gocourier' ),
				'condition' => ['posts_style' => ['style2']],
			]
        );
	
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Add Your Listing', 'gocourier' ),
				'placeholder' => esc_html__( 'Type your title here', 'gocourier' ),
			]
        );
        
        $this->add_control(
			'services_description',
			[
				'label' => esc_html__( 'Description', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'rows' => 10,
				'default' => esc_html__( 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'gocourier' ),
				'placeholder' => esc_html__( 'Type your description here', 'gocourier' ),
			]
        );

        $this->add_control(
			'services_image',
			[
				'label' => esc_html__( 'Choose Image', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'condition' => ['posts_style' => ['style1']],
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
        
        $this->add_responsive_control(
            'text_align', [
                'label'          => esc_html__( 'Alignment', 'gocourier'  ),
                'type'           => Controls_Manager::CHOOSE,
                'options'        => [
    
                    'left'         => [
                        'title'    => esc_html__( 'Left', 'gocourier'  ),
                        'icon'     => 'fa fa-align-left',
                    ],
                    'center'     => [
                        'title'    => esc_html__( 'Center', 'gocourier'  ),
                        'icon'     => 'fa fa-align-center',
                    ],
                    'right'         => [
                        'title'     => esc_html__( 'Right', 'gocourier'  ),
                        'icon'     => 'fa fa-align-right',
                    ],
                ],
               'default'         => 'center',
               'selectors' => [
                   '{{WRAPPER}} .services-content' => 'text-align: {{VALUE}};'
               ],
            ]
        );
 

        $this->add_responsive_control(
			'padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .services-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
        $this->end_controls_section();

        // Number style tab //
		
		$this->start_controls_section(
			'style_number_section',
			[
				'label' => esc_html__( 'Title and Description', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'number_color',
			[
				'label' => esc_html__( 'Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-box h3, {{WRAPPER}} .service-box h5' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'number_border_color',
			[
				'label' => esc_html__( 'Description Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-box p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Title Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .service-box h3, {{WRAPPER}} .service-box h5',
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'des_typography',
				'label' => esc_html__( 'Description Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .service-box p',
			]
		);
		
		$this->add_control(
			'number_2_color',
			[
				'label' => esc_html__( 'Number Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .style2 .icon-container' => 'color: {{VALUE}}',
				],
				'condition' => ['posts_style' => ['style2']],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'num_typography',
				'label' => esc_html__( 'Number Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .style2 .icon-container',
				'condition' => ['posts_style' => ['style2']],
			]
		);
       
      $this->end_controls_section();

    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="services-content <?php echo esc_attr($settings['posts_style']); ?>">
        	<?php if($settings['posts_style'] == 'style2'): ?>
            <div class="service-box style2">
            	<?php if($settings['number'] != ''): ?>
                    <div class="icon-container"><?php echo esc_html($settings['number']); ?></div>
                <?php endif; ?>
                <div class="services-details">
					<?php if($settings['title'] != ''): ?>
                    <h5><?php echo esc_html($settings['title']); ?></h5>
                    <?php endif; ?>
                    
                    <?php if($settings['services_description'] != ''): ?>
                    <p><?php echo esc_html($settings['services_description']); ?></p>
                    <?php endif; ?>            
                </div>
            </div>
            <?php else: ?>
            <div class="service-box">
            	<?php if($settings['services_image']['url'] != ''): ?>
                    <div class="icon-container"><img src="<?php echo esc_html($settings['services_image']['url']); ?>" alt="<?php echo esc_attr__('service image', 'gocourier'); ?>"></div>
                <?php endif; ?>
                <div class="services-details">
					<?php if($settings['title'] != ''): ?>
                    <h5><?php echo esc_html($settings['title']); ?></h5>
                    <?php endif; ?>
                    
                    <?php if($settings['services_description'] != ''): ?>
                    <p><?php echo esc_html($settings['services_description']); ?></p>
                    <?php endif; ?>            
                </div>
            </div><!-- end service-box -->
            <?php endif; ?>
                   
        </div>

        <?php
	}

    protected function content_template() {}
}