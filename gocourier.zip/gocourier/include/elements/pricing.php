<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class GoCourier_Pricing extends Widget_Base {


  public $base;

    public function get_name() {
        return 'gocourier-pricing';
    }

    public function get_title() {

        return esc_html__( 'Pricing', 'gocourier'  );

    }

    public function get_icon() { 
        return 'fas fa-folder';
    }

    public function get_categories() {
        return [ 'gocourier-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'posts_style',
			[
				'label' => esc_html__( 'Style', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'gocourier' ),
					'style_2' => esc_html__( 'Style 2', 'gocourier' ),
				],
			]
		);
	
		$this->add_control(
			'number_of_posts',
			[
				'label' => esc_html__( 'Number of Pricing', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 12,
				'step' => 1,
				'default' => 3,
			]
		);
		
		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC'  => esc_html__( 'DESC', 'gocourier' ),
					'ASC' => esc_html__( 'ASC', 'gocourier' ),
				],
			]
		);
		
		$this->add_control(
			'orderby',
			[
				'label' => esc_html__( 'Order By', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'title'  => esc_html__( 'Title', 'gocourier' ),
					'date' => esc_html__( 'Date', 'gocourier' ),
					'ID'  => esc_html__( 'ID', 'gocourier' ),
					'name'  => esc_html__( 'Name', 'gocourier' ),
					'rand' => esc_html__( 'Rand', 'gocourier' ),
					'comment_count'  => esc_html__( 'Comment Count', 'gocourier' ),
					'menu_order' => esc_html__( 'Menu Order', 'gocourier' ),					
					'author' => esc_html__( 'Author', 'gocourier' ),
				],
			]
		);
		
		$this->add_control(
			'seleceted_pricing_list',
			[
				'label' => esc_html__( 'Select Pricing', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => $this->selected_pricings(),
				'label_block' => true,
				'multiple'		=> true,
			]			
		);	
		
		
		$this->end_controls_section();

		// Style Section //
		
		$this->start_controls_section(
			'featured_bg_section',
			[
				'label' => esc_html__( 'Featured', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'featured_tabs_con'
		);
		
		$this->start_controls_tab(
			'featured_normal_tab_con',
			[
				'label' => esc_html__( 'Normal', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'featured_color_con',
			[
				'label' => esc_html__( 'Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-header h3' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_con_bg',
			[
				'label' => esc_html__( 'Title BG Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-header h3' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_con_bg_button',
			[
				'label' => esc_html__( 'Button Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-footer a' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_content_bg_border',
			[
				'label' => esc_html__( 'Price Box Border Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-box' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'featured_hover_tab_con',
			[
				'label' => esc_html__( 'Hover', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'featured_color_hover_con',
			[
				'label' => esc_html__( 'Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-header:hover h3' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_con_bg_hov',
			[
				'label' => esc_html__( 'Title BG Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-header:hover h3' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_con_bg_button_hover',
			[
				'label' => esc_html__( 'Button Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-footer a:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_content_bg_border_hover',
			[
				'label' => esc_html__( 'Price BOx Border Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-box:hover' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_control(
			'hr',
			[
				'type' => \Elementor\Controls_Manager::DIVIDER,
			]
		);
		
		$this->add_control(
			'featured_color_price',
			[
				'label' => esc_html__( 'Price Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-price p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_price_des',
			[
				'label' => esc_html__( 'Price Des Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-desc p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_content',
			[
				'label' => esc_html__( 'Content Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-description h4' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'featured_color_content_span',
			[
				'label' => esc_html__( 'Content Span Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-description h4 span' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_control(
			'featured_color_content_bg_sec',
			[
				'label' => esc_html__( 'Price BOx BG Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-box' => 'background-color: {{VALUE}}',
				],
			]
		);
	  
	  $this->add_responsive_control(
			'meta_padding_con_color_feature',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .featured-on .pricing-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
		
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Title', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'title_tabs'
		);
		
		$this->start_controls_tab(
			'title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-header h3' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'title_bg_color',
			[
				'label' => esc_html__( 'Title BG Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-header h3' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'title_color_border',
			[
				'label' => esc_html__( 'Title Border Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-header:after' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'title_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'title_color_hover',
			[
				'label' => esc_html__( 'Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-header:hover h3' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'title_bg_color_hover',
			[
				'label' => esc_html__( 'Title BG Hover Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-header:hover h3' => 'background-color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'title_color_border_hover',
			[
				'label' => esc_html__( 'Title Border Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-box:hover .pricing-header:after' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .pricing-header h3',
			]
		);

        $this->add_responsive_control(
			'title_padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing-header h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Style Cause Section //
		
		$this->start_controls_section(
			'cause_section',
			[
				'label' => esc_html__( 'Price', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'cause_color',
			[
				'label' => esc_html__( 'Price Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-price p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Description Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-desc p' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'cause_typography',
				'label' => esc_html__( 'Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .pricing-price p',
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'des_typography',
				'label' => esc_html__( 'Description Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .pricing-desc p',
			]
		);

        $this->add_responsive_control(
			'cause_padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing-price' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  // Meta Style Section //
		
		$this->start_controls_section(
			'meta_section',
			[
				'label' => esc_html__( 'Button', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'meta_tabs'
		);
		
		$this->start_controls_tab(
			'meta_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'meta_color',
			[
				'label' => esc_html__( 'Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-footer .pricing-button' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'meta_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-footer .pricing-button i' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'meta_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'meta_color_hover',
			[
				'label' => esc_html__( 'Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-footer .pricing-button:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'meta_hover_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-footer .pricing-button:hover i' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'meta_typography',
				'label' => esc_html__( 'Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .pricing-footer .pricing-button',
			]
		);

        $this->add_responsive_control(
			'meta_padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing-footer' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
	  
	  $this->add_control(
			'meta_content_color',
			[
				'label' => esc_html__( 'Content Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-description .panel-title' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'meta_content_color_span',
			[
				'label' => esc_html__( 'Content Span Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-description .panel-title span' => 'color: {{VALUE}}',
				],
			]
		);
       
      $this->end_controls_section();
	  
	  $this->start_controls_section(
			'content_bg_section',
			[
				'label' => esc_html__( 'Content', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'meta_tabs_con'
		);
		
		$this->start_controls_tab(
			'meta_normal_tab_con',
			[
				'label' => esc_html__( 'Normal', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'meta_color_con',
			[
				'label' => esc_html__( 'Border Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-box' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'meta_hover_tab_con',
			[
				'label' => esc_html__( 'Hover', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'meta_color_hover_con',
			[
				'label' => esc_html__( 'Border Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .pricing-box:hover' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();

        $this->add_responsive_control(
			'meta_padding_con',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
		
    }

    protected function render( ) { 
        $settings = $this->get_settings_for_display();
		
		$args = array(
		'post_type' => 'pricing',
		'posts_per_page' => $settings['number_of_posts'],
		'order'          => $settings['order'],
		'orderby'        => $settings['orderby'],
		);
		
		if(!empty($settings['seleceted_pricing_list'])){
			$args['post__in'] = $settings['seleceted_pricing_list'];
		}
		
		$query = get_posts( $args );
		?>
        
		<div class="pricing-content ts-pricing pricing-tables text-center <?php echo esc_attr($settings['posts_style']); ?>">
				<?php
				if ($query): ?>
                <div class="row justify-content-center">
                    <?php foreach ( $query as $post ): ?>
                    <?php 
					$featured = get_post_meta( $post->ID, 'featured', true );
					$featured_class = ( $featured == 'off' )? 'featured-off' : 'featured-on';
					?>
                    <div class="col-md-4 col-sm-6 col-xs-12 <?php echo esc_attr($featured_class); ?>">
                    	<div class="pricing-box transition">
                             
                            <div class="pricing-price">
                            	<?php if($settings['posts_style'] == 'style2'): ?>
                                <div class="pricing-header">
                                    <h3><?php echo get_the_title($post->ID); ?></h3>
                                </div>
                                <?php endif; ?>
                            	<?php
                                $price_currency = get_post_meta( $post->ID, 'price_currency', true );
								$price_text = get_post_meta( $post->ID, 'price_text', true );
								?>
                                <p><?php echo esc_html($price_currency); ?><?php echo esc_html($price_text); ?></p>
                            </div><!-- end price -->
                            <div class="pricing-desc text-center">
                                <p><?php echo get_the_excerpt($post->ID); ?></p>
                            </div><!-- end desc -->
                            <?php if($settings['posts_style'] == 'style1'): ?>
                            <div class="pricing-header">
                            	<h3><?php echo get_the_title($post->ID); ?></h3>
                            </div>
                            <?php endif; ?>
                            
                            <div class="pricing-description">                               
                                <?php 
								$feature_info = get_post_meta( $post->ID, 'feature_info', true );
								if(!empty($feature_info)):
								foreach( $feature_info as $value ):
								?>
                                    <h4 class="panel-title">
                                        <?php echo esc_html($value['title']); ?>
                                        <span><?php echo esc_html($value['feature_text']); ?></span>                                           
                                    </h4>
                                <?php
								endforeach;
								endif; ?>
                            </div><!-- end panel-group -->
                            
                            <div class="pricing-footer text-center">
                            	<?php 
								$button_link = get_post_meta( $post->ID, 'button_link', true );
								$button_text = get_post_meta( $post->ID, 'button_text', true );
								?>
                                <a href="<?php echo esc_url($button_link); ?>" class="pricing-button transition"><?php echo esc_html($button_text); ?> <i class="fa fa-arrow-right transition" aria-hidden="true"></i>
</a>
                            </div><!-- end desc -->
                        </div>                                          
                    </div>
                    <?php
					endforeach;
					?>
                </div>
            <?php endif; ?>       
		</div>
    	<?php
    }
    protected function content_template() {}
	
	public function selected_pricings(){
		$list = [];
		$args = array(
		'post_type' => 'pricing',
		'posts_per_page' => -1,
		);
		$posts = get_posts( $args );		
		if(!empty($posts)){
			foreach ( $posts as $post ) {
				$list[$post->ID] = [get_the_title($post->ID)];
			}
		}
		return $list;
	}
	
}