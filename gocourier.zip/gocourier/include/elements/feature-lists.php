<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class GoCourier_Feature_Lists extends Widget_Base {


  public $base;

    public function get_name() {
        return 'gocourier-feature-lists';
    }

    public function get_title() {

        return esc_html__( 'Feature Lists', 'gocourier'  );

    }

    public function get_icon() { 
        return 'fas fa-handshake';
    }

    public function get_categories() {
        return [ 'gocourier-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
		
		$repeater = new \Elementor\Repeater();
	
		$repeater->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Feature 1', 'gocourier' ),
				'placeholder' => esc_html__( 'Type your feature title here', 'gocourier' ),
				'label_block' => true,
			]
        );
		
		
		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Partner List', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title' => esc_html__( 'Title #1', 'gocourier' ),
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);
		
		$this->add_responsive_control(
            'text_align', [
                'label'          => esc_html__( 'Alignment', 'gocourier'  ),
                'type'           => Controls_Manager::CHOOSE,
                'options'        => [
    
                    'left'         => [
                        'title'    => esc_html__( 'Left', 'gocourier'  ),
                        'icon'     => 'fas fa-align-left',
                    ],
                    'center'     => [
                        'title'    => esc_html__( 'Center', 'gocourier'  ),
                        'icon'     => 'fas fa-align-center',
                    ],
                    'right'         => [
                        'title'     => esc_html__( 'Right', 'gocourier'  ),
                        'icon'     => 'fas fa-align-right',
                    ],
                ],
               'default'         => 'center',
               'selectors' => [
                   '{{WRAPPER}} .featured-lists' => 'text-align: {{VALUE}};'
               ],
            ]
        );
		
		$this->add_responsive_control(
			'feature_padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .featured-lists' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
       
        $this->end_controls_section();
		
		// Icon Style Section //
		
		$this->start_controls_section(
			'icon_style_section',
			[
				'label' => esc_html__( 'Style', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .feature-list li h4, {{WRAPPER}} .feature-list li:before' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => esc_html__( 'Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .feature-list li h4',
			]
		);
       
	  $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
		
		if ( $settings['list'] ): ?>
        <div class="featured-lists">
            <ul class="feature-list">         
                <?php foreach ( $settings['list'] as $item ): ?>
                <li class="list">
                    <h4><?php echo esc_html($item['title']); ?></h4>
                </li>                
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php
	}

    protected function content_template() {}
}