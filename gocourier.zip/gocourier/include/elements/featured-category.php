<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class GoCourier_Featured_Category extends Widget_Base {


  public $base;

    public function get_name() {
        return 'gocourier-featured-cateogry';
    }

    public function get_title() {

        return esc_html__( 'Featured Category', 'gocourier'  );

    }

    public function get_icon() { 
        return 'fas fa-folder';
    }

    public function get_categories() {
        return [ 'gocourier-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'cat_style',
			[
				'label' => esc_html__( 'Style', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'gocourier' ),
					'style2' => esc_html__( 'Style 2', 'gocourier' ),
				],
			]
		);
	
		$this->add_control(
			'number_of_category',
			[
				'label' => esc_html__( 'Number of Category', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100,
				'step' => 1,
				'default' => 9,
			]
		);
		
		$this->add_control(
			'cateogries',
			[
				'label' => esc_html__( 'Select Categories', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => $this->get_product_cat(),
				'label_block' => true,
				'multiple'		=> true,
			]			
		);		
		
		
		$this->end_controls_section();

		// Category Style Section //
		
		$this->start_controls_section(
			'category_style_section',
			[
				'label' => esc_html__( 'Category', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'category_color',
			[
				'label' => esc_html__( 'Category Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cat-list-column h5' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'category_typography',
				'label' => esc_html__( 'Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .cat-list-column h5',
			]
		);
		
		$this->add_control(
			'category_color_hover',
			[
				'label' => esc_html__( 'Category Color Hover', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cat-list-column h5:hover' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'border_color',
			[
				'label' => esc_html__( 'Border Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cat-list-column' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'border_color_hover',
			[
				'label' => esc_html__( 'Border Color Hover', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .cat-list-column:hover' => 'border-color: {{VALUE}}',
				],
			]
		);
       
	  $this->end_controls_section();
		
    }

    protected function render( ) { 
        $settings = $this->get_settings_for_display();		
		
		$args = array(
					'taxonomy' 		=> 'product_cat',
					'hide_empty' 	=> true,
					'number'		=> $settings['number_of_category'],
					'include'		=> $settings['cateogries'],
					
				);
 
		$terms = get_terms( $args );
		?>
        
		<div class="featured-category">
			<?php if($settings['cat_style'] == 'style2'): ?>
            	
            <?php else: ?>
				<?php
                $i = 0;
				$class = '';
				if ( ! empty( $terms ) && ! is_wp_error( $terms ) ): ?>
                <ul class="cat-lists text-center">
                    <?php foreach ( $terms as $term ):
					if($i == 4){
						$class = ' last';
					} else{
						$class = '';
					}
					$args = array(
					'post_type' => 'product',
					'tax_query' => array(
						array(
						'taxonomy' => 'product_cat',
						'field' => 'term_id',
						'terms' => $term->term_id
						 )
					  )
					);
					$query = get_posts( $args );
                    ?>
                    <li class="cat-list-column<?php echo esc_attr($class); ?>">
                    	<a href="<?php echo esc_url( get_term_link( $term ) ); ?>">
                            <span class="product-count">0<?php echo esc_html(count($query)); ?></span>
                            <?php $term_image = get_term_meta( $term->term_id, 'thumbnail_id', true); ?>
                            <?php if($term_image != ''): ?>
                            <img src="<?php echo esc_url(wp_get_attachment_url($term_image)); ?>" alt="<?php echo esc_attr($term->name); ?>" />
                            <?php endif; ?>
                            <h5><?php echo esc_html($term->name); ?></h5>
                        </a>                        
                    </li>
                    <?php
					if($i == 4){
						$i = 0;
					} else{
						$i++;
					}					
					endforeach; ?>
                </ul>
                <?php endif; ?>
            <?php endif; ?>       
		</div>
    	<?php  
    }
    protected function content_template() {}
	
	public function get_product_cat(){
		$args = array( 'hide_empty=0' );
		$terms = get_terms( 'product_cat', $args );
		$product_cat = [];
		foreach ( $terms as $term ) {
			$product_cat[$term->term_id] = [$term->name];
		}
		return $product_cat;
	}
}