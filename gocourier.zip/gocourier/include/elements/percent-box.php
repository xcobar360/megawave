<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class GoCourier_Percent_Box extends Widget_Base {


  public $base;

    public function get_name() {
        return 'gocourier-percentbox';
    }

    public function get_title() {

        return esc_html__( 'Text Box', 'gocourier'  );

    }

    public function get_icon() { 
        return 'fas fa-flag';
    }

    public function get_categories() {
        return [ 'gocourier-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
        );
		
		$this->add_control(
			'percent_title',
			[
				'label' => esc_html__( 'Title', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'What We Do', 'gocourier' ),
				'placeholder' => esc_html__( 'Type your title here', 'gocourier' ),
			]
        );
		
		$this->add_control(
			'percent_text1',
			[
				'label' => esc_html__( 'Text 1', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip. quis nostrud.', 'gocourier' ),
				'placeholder' => esc_html__( 'Type your text here', 'gocourier' ),
			]
        );        
        
        $this->add_responsive_control(
            'text_align', [
                'label'          => esc_html__( 'Alignment', 'gocourier'  ),
                'type'           => Controls_Manager::CHOOSE,
                'options'        => [
    
                    'left'         => [
                        'title'    => esc_html__( 'Left', 'gocourier'  ),
                        'icon'     => 'fas fa-align-left',
                    ],
                    'center'     => [
                        'title'    => esc_html__( 'Center', 'gocourier'  ),
                        'icon'     => 'fas fa-align-center',
                    ],
                    'right'         => [
                        'title'     => esc_html__( 'Right', 'gocourier'  ),
                        'icon'     => 'fas fa-align-right',
                    ],
                ],
               'default'         => '',
               'selectors' => [
                   '{{WRAPPER}} .percent-box-content' => 'text-align: {{VALUE}};'
               ],
            ]
        );
 

        $this->add_responsive_control(
			'padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .percent-box-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
		$this->end_controls_section();
	  
	  // Number Style Section //
		
		$this->start_controls_section(
			'text_style_section',
			[
				'label' => esc_html__( 'Text', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ts-box-title' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'background_color',
			[
				'label' => esc_html__( 'Description Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ts-box-content' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'border_color',
			[
				'label' => esc_html__( 'Border Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .percent-box-content .ts-box' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => esc_html__( 'Title Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .ts-box-content .ts-box-title',
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'sign_typography',
				'label' => esc_html__( 'Description Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .ts-box-content',
			]
		);

        $this->add_responsive_control(
			'text_padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .percent-box-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
	  $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="percent-box-content">
            <div class="ts-box ts-box-style-default">
                <div class="ts-box-title"><?php echo esc_html($settings['percent_title']); ?></div>
                <div class="ts-box-content ts-clearfix"><?php echo esc_html($settings['percent_text1']); ?></div>
            </div>            
        </div>
        <?php
	}

    protected function content_template() {}
}