<?php

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


class GoCourier_Title extends Widget_Base {


  public $base;

    public function get_name() {
        return 'gocourier-title';
    }

    public function get_title() {

        return esc_html__( 'Title', 'gocourier'  );

    }

    public function get_icon() { 
        return 'fas fa-heading';
    }

    public function get_categories() {
        return [ 'gocourier-all-elements' ];
    }

    protected function register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'title_style',
			[
				'label' => esc_html__( 'Style', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style1',
				'options' => [
					'style1'  => esc_html__( 'Style 1', 'gocourier' ),
					'style2' => esc_html__( 'Style 2', 'gocourier' ),
				],
			]
		);
	
		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'About Us', 'gocourier' ),
				'placeholder' => esc_html__( 'Type your title here', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'bg_title',
			[
				'label' => esc_html__( 'BG Title', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'About', 'gocourier' ),
				'placeholder' => esc_html__( 'Type your bg-title here', 'gocourier' ),
				'condition' => ['title_style' => ['style1']],
			]
		);
		
		$this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'Type your sub-title here', 'gocourier' ),
			]
		);		
		
		$this->add_responsive_control(
            'text_align', [
                'label'          => esc_html__( 'Alignment', 'gocourier'  ),
                'type'           => Controls_Manager::CHOOSE,
                'options'        => [
    
                    'left'         => [
                        'title'    => esc_html__( 'Left', 'gocourier'  ),
                        'icon'     => 'fas fa-align-left',
                    ],
                    'center'     => [
                        'title'    => esc_html__( 'Center', 'gocourier'  ),
                        'icon'     => 'fas fa-align-center',
                    ],
                    'right'         => [
                        'title'     => esc_html__( 'Right', 'gocourier'  ),
                        'icon'     => 'fas fa-align-right',
                    ],
                ],
               'default'         => 'center',
               'selectors' => [
                   '{{WRAPPER}} .heading-content' => 'text-align: {{VALUE}};'
               ],
            ]
        );
		
		$this->end_controls_section();

		// Style Section //
		
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Title', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'title_tabs'
		);
		
		$this->start_controls_tab(
			'title_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title h3 .colored-text, {{WRAPPER}} .ts-title-style2 h3' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'title_span_color',
			[
				'label' => esc_html__( 'Title Span Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ts-title-style2 h3 span' => 'color: {{VALUE}}',
				],
				'condition' => ['title_style' => ['style2']],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'title_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'title_color_hover',
			[
				'label' => esc_html__( 'Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title:hover h3 .colored-text, {{WRAPPER}} .ts-title-style2:hover h3' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'title_span_color_hover',
			[
				'label' => esc_html__( 'Title Span Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ts-title-style2 h3 span' => 'color: {{VALUE}}',
				],
				'condition' => ['title_style' => ['style2']],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Description Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .ts-title-style2 p' => 'color: {{VALUE}}',
				],
				'condition' => ['title_style' => ['style2']],
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'label' => esc_html__( 'Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .section-title h3 .font-backend, {{WRAPPER}} .ts-title-style2 h3',
			]
		);
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'description_typography',
				'label' => esc_html__( 'Description Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .ts-title-style2 p',
				'condition' => ['title_style' => ['style2']],
			]
		);

        $this->add_responsive_control(
			'title_padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .section-title h3 .font-backend, {{WRAPPER}} .ts-title-style2 h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  $this->start_controls_section(
			'style_sub_section',
			[
				'label' => esc_html__( 'Sub Title', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => ['title_style' => ['style1']],
			]
		);
		
		$this->start_controls_tabs(
			'subtitle_tabs'
		);
		
		$this->start_controls_tab(
			'subtitle_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'subtitle_color',
			[
				'label' => esc_html__( 'Sub Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title .lead' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'subtitle_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'subtitle_color_hover',
			[
				'label' => esc_html__( 'Sub Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title:hover .lead' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'sub_title_typography',
				'label' => esc_html__( 'Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .section-title .lead',
			]
		);

        $this->add_responsive_control(
			'sub_title_padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .section-title .lead' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
      $this->end_controls_section();
	  
	  $this->start_controls_section(
			'style_bg_section',
			[
				'label' => esc_html__( 'BG Title', 'gocourier' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				'condition' => ['title_style' => ['style1']],
			]
		);
		
		$this->start_controls_tabs(
			'bgtitle_tabs'
		);
		
		$this->start_controls_tab(
			'bgtitle_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'bgtitle_color',
			[
				'label' => esc_html__( 'BG Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title h3 .font-backend' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->start_controls_tab(
			'bgtitle_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'gocourier' ),
			]
		);
		
		$this->add_control(
			'bgtitle_color_hover',
			[
				'label' => esc_html__( 'Sub Title Color', 'gocourier' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .section-title:hover h3 .font-backend' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->end_controls_tab();
		
		$this->end_controls_tabs();
		
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'bg_title_typography',
				'label' => esc_html__( 'Typography', 'gocourier' ),
				'selector' => '{{WRAPPER}} .section-title h3 .font-backend',
			]
		);

        $this->add_responsive_control(
			'bg_title_padding',
			[
				'label' =>esc_html__( 'Padding', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .section-title h3 .font-backend' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
	  
	  $this->add_responsive_control(
			'bg_title_margin',
			[
				'label' =>esc_html__( 'Margin', 'gocourier'  ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .section-title h3 .font-backend' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
      );
       
	  $this->end_controls_section();
	  
	  // End Style Section //
    }

    protected function render( ) { 
        $settings = $this->get_settings_for_display();
		?>
        
		<div class="heading-content <?php echo esc_attr($settings['text_align']); ?>">
			<?php if($settings['title_style'] == 'style2'): ?>
            	<div class="ts-title-style2">
                <h3>
                <?php if($settings['title'] != ''): ?>
                <?php echo wp_kses($settings['title'], array('span'=>array())); ?>
                <?php endif; ?>
                </h3>
                <?php if($settings['sub_title'] != ''): ?>
                <p><?php echo esc_html($settings['sub_title']); ?></p>
                <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="ts-title-style1 section-title">
                <h3>
                <?php if($settings['bg_title'] != ''): ?>
                <span class="font-backend"><?php echo esc_html($settings['bg_title']); ?></span>
                <?php endif; ?>
                <?php if($settings['title'] != ''): ?>
                <span class="colored-text"><?php echo wp_kses($settings['title'], array('span'=>array())); ?></span>
                <?php endif; ?>
                <span class="bottom-botder"></span>
                </h3>
                <?php if($settings['sub_title'] != ''): ?>
                <p class="lead"><?php echo esc_html($settings['sub_title']); ?></p>
                <?php endif; ?>
                </div>
            <?php endif; ?>       
		</div>
    	<?php  
    }
    protected function content_template() {}
}