<?php
require GOCOURIERTHEMEDIR . '/include/breadcrumbs.php';

function gocourier_excerpt_more( $more ) {
		return '<a class="read-more" href="' . esc_url(get_permalink( get_the_ID() ) ) . '">' . esc_html__('...', 'gocourier' ) . '</a>';
} // end gocourier_excerpt_more function

add_filter( 'excerpt_more', 'gocourier_excerpt_more' );

function gocourier_excerpt_length( $length ) {
	$length = (function_exists('ot_get_option'))? ot_get_option( 'excerpt_length', 20 ) : 20;
	if( $length!= ''){
		return $length;
	} else{
	return 20;
	}	
} // end gocourier_excerpt_length function

add_filter( 'excerpt_length', 'gocourier_excerpt_length', 999 );

if ( ! function_exists( 'gocourier_comment_form' ) ) :
// gocourier comments form
function gocourier_comment_form( $args = array(), $post_id = null ) {
	if ( null === $post_id )
		$post_id = get_the_ID();
	else
		$id = $post_id;

	$commenter = wp_get_current_commenter();
	$user = wp_get_current_user();
	$user_identity = $user->exists() ? $user->display_name : '';

	if ( ! isset( $args['format'] ) )
		$args['format'] = current_theme_supports( 'html5', 'comment-form' ) ? 'html5' : 'xhtml';

	$req      = get_option( 'require_name_email' );
	$aria_req = ( $req ? " aria-required='true'" : '' );
	$html5    = 'html5' === $args['format'];

	$comments_field = '<textarea id="comment" name="comment" aria-required="true" cols="30" rows="5" placeholder="' . esc_attr__( 'Message Below', 'gocourier' ) . '" class="form-control"></textarea>';
	
	$fields   =  array(
		'author' => '<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" ' . $aria_req . ' placeholder="' . esc_attr__( 'Name', 'gocourier' ) . '" class="form-control" />',
		
		'email'  => '<input id="email" name="email" ' . ( $html5 ? 'type="email"' : 'type="text"' ) . ' value="' . esc_attr( $commenter['comment_author_email'] ) . '" ' . $aria_req . ' placeholder="' . esc_attr__( 'Email', 'gocourier' ) . '" class="form-control" />',
		
		'url' => '<input id="url" name="url" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) .'" placeholder="' . esc_attr__( 'Website', 'gocourier' ) . '" class="form-control" />',
	);
	
	$defaults = array(
		'fields'               => apply_filters( 'gocourier_comment_form_default_fields', $fields ),
		
		'comment_field'        => $comments_field,
		
		'must_log_in'          => '<p class="must-log-in">' . sprintf( wp_kses( __( 'You must be <a href="%s">logged in</a> to post a comment.', 'gocourier' ), array('a' => array(
					  'href' => array()),)) , wp_login_url( apply_filters( 'gocourier_the_permalink', esc_url(get_permalink( $post_id ) ) ) ) ) . '</p>',
		
		'logged_in_as'         => '<p class="logged-in-as">' . sprintf( wp_kses( __( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s">Log out?</a>', 'gocourier' ), array('a' => array('href' => array()),)) , esc_url(get_edit_user_link()), esc_html($user_identity), wp_logout_url( apply_filters( 'gocourier_the_permalink', esc_url(get_permalink( $post_id ) ) ) ) ) . '</p>',
		
		'id_form'              => 'commentform',
		'id_submit'            => 'submit',
		'title_reply'          => esc_html__( 'Leave a Comment', 'gocourier' ),
		'title_reply_to'       => esc_html__( 'Leave a Comment to %s', 'gocourier' ),
		'cancel_reply_link'    => esc_html__( 'Cancel Reply', 'gocourier' ),
		'label_submit'         => esc_html__( 'Submit Comment', 'gocourier' ),
		'format'               => 'xhtml',
	);

	$args = wp_parse_args( $args, apply_filters( 'gocourier_comment_form_defaults', $defaults ) );

	?>
		<?php if ( comments_open( $post_id ) ) : ?>
			<div class="widget last-form-comment">
                <div class="input-title">
					<h4><?php comment_form_title( $args['title_reply'], $args['title_reply_to'] ); ?>
					<?php cancel_comment_reply_link( $args['cancel_reply_link'] ); ?></h4>
                </div>
				<div class="contact_form" id="respond">
				<?php if ( get_option( 'comment_registration' ) && !is_user_logged_in() ) : ?>
					<?php echo wp_kses($args['must_log_in'],array(
					'a' => array(
					  'title' => array(),
					  'href' => array(),
					  'class' => array()
					),
					'span' => array(
					  'class' => array(),
					),
				  )); ?>
					<?php do_action( 'gocourier_comment_form_must_log_in_after' ); ?>
				<?php else : ?>
					<form action="<?php echo site_url( '/wp-comments-post.php' ); ?>" method="post" id="<?php echo esc_attr( $args['id_form'] ); ?>" class="contact-form"<?php echo esc_attr($html5) ? ' novalidate' : ''; ?>>
                    <?php if ( is_user_logged_in() ) : ?>
						<?php echo apply_filters( 'gocourier_comment_form_logged_in', $args['logged_in_as'], $commenter, $user_identity ); ?>
                    <?php endif; ?>
						
					<?php if ( is_user_logged_in() ) : ?>
                    <?php echo apply_filters( 'gocourier_comment_form_field_comment', $args['comment_field'] ); ?>
						<?php else : ?>
                            <?php
							foreach ( (array) $args['fields'] as $name => $field ) {
								echo apply_filters( "gocourier_comment_form_field_{$name}", $field ) . "\n";
							}
							?>
                            <?php echo apply_filters( 'gocourier_comment_form_field_comment', $args['comment_field'] ); ?>
						<?php endif; ?>                        
						<input class="btn btn-white btn-block" type="submit" id="<?php echo esc_attr( $args['id_submit'] ); ?>" value="<?php echo esc_attr( $args['label_submit'] ); ?>" />
                        <?php comment_id_fields( $post_id ); ?>
						<?php do_action( 'gocourier_comment_form', $post_id ); ?>
					</form>
				<?php endif; ?>
                </div>
			</div><!--.widget-->
		<?php else : ?>
			<?php do_action( 'gocourier_comment_form_comments_closed' ); ?>
		<?php endif; ?>
	<?php
} // end gocourier_comment_form function
endif;

function gocourier_body_class( $classes ) {

	if ( is_page_template( 'page-templates/home-page.php' ) ) {
		$homepage_header_layout = get_post_meta( get_the_ID(), 'homepage_header_layout', true );
		$classes[] = 'header-'.$homepage_header_layout;
	}
	if(is_page()){
		$layout = get_post_meta( get_the_ID(), 'page_layout', true );
		if($layout != ''){
			$layout = $layout;
		} else {
			$layout = 'rs';
		}
	}
	elseif(is_single()){
		$layout = (function_exists('ot_get_option'))? ot_get_option( 'single_layout', 'rs' ) : 'rs';
	}
	else{
		$layout = (function_exists('ot_get_option'))? ot_get_option( 'blog_layout', 'rs' ) : 'rs';
	}
	
	$classes[] = 'layout-'.$layout;

	return $classes;
}
add_filter( 'body_class', 'gocourier_body_class' );

 if ( ! function_exists( 'gocourier_comments' ) ) :
/**
 * Template for comments and pingbacks.
 *
 * To override this walker in a child theme without modifying the comments template
 * simply create your own gocourier_comment(), and that function will be used instead.
 *
 * Used as a callback by wp_list_comments() for displaying the comments.
 *
 */
function gocourier_comments( $comment, $args, $depth ) {
	$GLOBALS['comment'] = $comment;
	switch ( $comment->comment_type ) :
		case 'pingback' :
		case 'trackback' :
		// Display trackbacks differently than normal comments.
	?>
    <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
		<p><?php esc_html_e( 'Pingback:', 'gocourier' ); ?> <?php comment_author_link(); ?> <?php edit_comment_link( esc_html__( 'Edit', 'gocourier' ), '<span class="edit-link">', '</span>' ); ?></p>
	<?php
			break;
		default :
		// Proceed with normal comments.
		global $post;
	?>
	<li <?php comment_class('comment-list'); ?> id="li-comment-<?php comment_ID(); ?>">
    	<div class="media"><div class="media-left">
            <a href="<?php echo esc_url(get_comment_author_link()); ?>"><?php echo get_avatar( $comment, 65 ); ?></a>
        </div>
        <div class="media-body">
        	<h4 class="media-heading">
				<?php printf( '%1$s %2$s', get_comment_author_link(), ( $comment->user_id === $post->post_author ) ? '<span>' . esc_html__( 'Post author', 'gocourier' ) . '</span>' : ''
                );
                ?>
                <span class="time-comment">
					<?php
                    printf( '<small>%3$s</small>', esc_url( get_comment_link( $comment->comment_ID ) ), get_comment_time( 'c' ),
                        /* translators: 1: date, 2: time */
                        sprintf( esc_html__( '%1$s at %2$s', 'gocourier' ), get_comment_date(), get_comment_time() )
                    );
                    ?>
                    <?php
                    edit_comment_link( esc_html__( 'Edit', 'gocourier' ), '<span class="cedit-link">', '</span>' );
                    comment_reply_link( array_merge( $args, array( 'reply_text' => esc_html__( 'Reply', 'gocourier' ), 'after' => '', 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) );
                    ?>
                </span>                
             </h4>
             <p><?php comment_text(); ?></p>
             <?php if ( '0' == $comment->comment_approved ) : ?>
                <p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'gocourier' ); ?></p>
                <?php endif; ?>
         </div>
         </div>							
	<?php
		break;
	endswitch; // end comment_type check
} // end gocourier_comments function
endif;

function gocourier_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'gocourier_categories' ) ) ) {
		// Create an array of all the categories that are attached to posts.
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'gocourier_categories', $all_the_cool_cats );
	}

	if ( $all_the_cool_cats > 1 ) {
		// This blog has more than 1 category so gocourier_categorized_blog should return true.
		return true;
	} else {
		// This blog has only 1 category so gocourier_categorized_blog should return false.
		return false;
	}
} // end gocourier_categorized_blog function

if ( ! function_exists( 'gocourier_category_transient_flusher' ) ) :
function gocourier_category_transient_flusher() {
	// Like, beat it. Dig?
	delete_transient( 'gocourier_categories' );
} // end gocourier_category_transient_flusher function
endif;

add_action( 'edit_category', 'gocourier_category_transient_flusher' );
add_action( 'save_post',     'gocourier_category_transient_flusher' );

if ( ! function_exists( 'gocourier_fonts_url' ) ) :
function gocourier_fonts_url() {
	$fonts_url = '';
	$fonts     = array();

	/* translators: If there are characters in your language that are not supported
	 * by Open Sans, translate this to 'off'. Do not translate into your own language.
	 */
	
	if ( 'off' !== _x( 'on', 'Roboto font: on or off', 'gocourier' ) ) {
		$fonts[] = 'Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900';
	}
	
	if ( 'off' !== _x( 'on', 'Poppins font: on or off', 'gocourier' ) ) {
		$fonts[] = 'Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900';
	}
	
	if ( $fonts ) {
		$fonts_url = add_query_arg( array(
			'family' => implode( '&family=', $fonts )
		), '//fonts.googleapis.com/css2' );
	}

	return $fonts_url;
} // end gocourier_fonts_url function
endif;

if ( ! function_exists( 'gocourier_mce_css' ) ) :
function gocourier_mce_css( $mce_css ) {
	$fonts_url = gocourier_fonts_url();

	if ( empty( $fonts_url ) )
		return $mce_css;

	if ( ! empty( $mce_css ) )
		$mce_css .= ',';

	$mce_css .= esc_url_raw( str_replace( ',', '%2C', $fonts_url ) );

	return $mce_css;
} // end gocourier_mce_css function
endif;

add_filter( 'mce_css', 'gocourier_mce_css' );

if ( ! function_exists( 'gocourier_fix_gallery' ) ) :
function gocourier_fix_gallery($output, $attr) {
    global $post;

    static $instance = 0;
    $instance++;
    $size_class = '';

    if ( isset( $attr['orderby'] ) ) {
        $attr['orderby'] = sanitize_sql_orderby( $attr['orderby'] );
        if ( !$attr['orderby'] )
            unset( $attr['orderby'] );
    }

    extract(shortcode_atts(array(
        'order'      => 'ASC',
        'orderby'    => 'menu_order ID',
        'id'         => $post->ID,
        'itemtag'    => 'div',
        'icontag'    => 'dt',
        'captiontag' => 'dd',
        'columns'    => 3,
        'size'       => '',
        'include'    => '',
        'exclude'    => ''
    ), $attr));

    $id = intval($id);
    if ( 'RAND' == $order )
        $orderby = 'none';

    if ( !empty($include) ) {
        $include = preg_replace( '/[^0-9,]+/', '', $include );
        $_attachments = get_posts( array('include' => $include, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );

        $attachments = array();
        foreach ( $_attachments as $key => $val ) {
            $attachments[$val->ID] = $_attachments[$key];
        }
    } elseif ( !empty($exclude) ) {
        $exclude = preg_replace( '/[^0-9,]+/', '', $exclude );
        $attachments = get_children( array('post_parent' => $id, 'exclude' => $exclude, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    } else {
        $attachments = get_children( array('post_parent' => $id, 'post_status' => 'inherit', 'post_type' => 'attachment', 'post_mime_type' => 'image', 'order' => $order, 'orderby' => $orderby) );
    }

    if ( empty($attachments) )
        return '';

    if ( is_feed() ) {
        $output = "\n";
        foreach ( $attachments as $att_id => $attachment )
            $output .= wp_get_attachment_link($att_id, $size, true) . "\n";
        return $output;
    }

    $itemtag = tag_escape($itemtag);
    $captiontag = tag_escape($captiontag);
    $columns = intval($columns);
    $itemwidth = $columns > 0 ? floor(100/$columns) : 100;
    $float = is_rtl() ? 'right' : 'left';

    $selector = "gallery-{$instance}";

    $gallery_style = $gallery_div = '';
    if ( apply_filters( 'use_default_gallery_style', true ) )

    $size_class = ($size != '' )?sanitize_html_class( $size ) : 'normal';
    $gallery_div = '<div id="'.esc_attr($selector).'" class="row gallery galleryid-'.esc_attr($id).'">';
    $output = apply_filters( 'gallery_style', $gallery_style . "\n\t\t" . $gallery_div );

	$width = round(1250/$columns);
	$height = round(1250/$columns);
	
	$col_class = intval(12/$columns);
	
    foreach ( $attachments as $id => $attachment ) {

        $link = isset($attr['link']) && 'file' == $attr['link'] ? wp_get_attachment_link($id, $size, false, false) : wp_get_attachment_link($id, $size, true, false);
		 $image_url = wp_get_attachment_url($id, $size, false, false);
		 $attatchement_image = gocourier_image_resize( $image_url, $width, $height, true, false, false );
        
		$output .= '<div class="col-lg-'.esc_attr($col_class).' col-md-'.esc_attr($col_class).' col-sm-4 col-xs-12 img-content">';
        $output .= '<a href="' .esc_url($image_url). '" ><img src="' . esc_url($attatchement_image) . '" alt="'.esc_attr__('images thumbnail', 'gocourier').'" /></a>
            </div>';  
    }
    $output .= '</div>';
    return $output;
} // end gocourier_fix_gallery function
endif;

add_filter("post_gallery", "gocourier_fix_gallery",10,2);


if ( ! function_exists( 'gocourier_posts_nav' ) ) :
function gocourier_posts_nav() {

	if( is_singular() )
		return;

	global $wp_query;

	/** Stop execution if there's only 1 page */
	if( $wp_query->max_num_pages <= 1 ) {

	} else {
	$paged = get_query_var( 'paged' ) ? absint( get_query_var( 'paged' ) ) : 1;
	$max   = intval( $wp_query->max_num_pages );

	/**	Add current page to the array */
	if ( $paged >= 1 )
		$links[] = $paged;

	/**	Add the pages around the current page to the array */
	if ( $paged >= 3 ) {
		$links[] = $paged - 1;
		$links[] = $paged - 2;
	}

	if ( ( $paged + 2 ) <= $max ) {
		$links[] = $paged + 2;
		$links[] = $paged + 1;
	}

	echo '<div class="blog-navigation"><ul class="pagination">' . "\n";

	/**	Previous Post Link */
	if ( get_previous_posts_link() )
		printf( '<li>%s</li>' . "\n", get_previous_posts_link( '<i class="fa fa-angle-left"></i>' ) );

	/**	Link to first page, plus ellipses if necessary */
	if ( ! in_array( 1, $links ) ) {
		$class = 1 == $paged ? 'list-nav current' : 'list-nav';

		printf( '<li class="%s"><a href="%s">%s</a></li>' . "\n", esc_attr($class), esc_url( get_pagenum_link( 1 ) ), '1' );

		if ( ! in_array( 2, $links ) )
			echo '<li>&hellip;</li>';
	}

	/**	Link to current page, plus 2 pages in either direction if necessary */
	sort( $links );
	foreach ( (array) $links as $link ) {
		$class = $paged == $link ? 'list-nav current' : 'list-nav';
		printf( '<li class="%s"><a href="%s">%s</a></li>' . "\n", esc_attr($class), esc_url( get_pagenum_link( $link ) ), $link );
	}

	/**	Link to last page, plus ellipses if necessary */
	if ( ! in_array( $max, $links ) ) {
		if ( ! in_array( $max - 1, $links ) )
			echo '<li>&hellip;</li>' . "\n";

		$class = $paged == $max ? 'list-nav current' : 'list-nav';
		printf( '<li class="%s"><a href="%s">%s</a></li>' . "\n", esc_attr($class), esc_url( get_pagenum_link( $max ) ), $max );
	}

	/**	Next Post Link */
	if ( get_next_posts_link() )
		printf( '<li>%s</li>' . "\n", get_next_posts_link( '<i class="fa fa-angle-right"></i>' ) );

	echo '</ul></div>' . "\n";

} // end gocourier_posts_nav function
}
endif;

function gocourier_next_prev_posts() {
	?>					
	<div class="post-navi">
    <?php
	$prev_post = get_previous_post();
	$title = '';
	if (!empty( $prev_post )){
		$title = $prev_post->post_title;
		if($title != ''){
			$title = $prev_post->post_title;
		} else {
			$title = get_the_date( 'd M Y', $prev_post->ID );
		}
	?>
    <a href="<?php echo esc_url(get_permalink( $prev_post->ID )); ?>" class="post-pagi"><i class="fa fa-angle-left"></i><?php echo esc_html($title); ?></a>
	<?php }
						
	$next_post = get_next_post();
	$title2 = '';
	if (!empty( $next_post )){
		$title2 = $next_post->post_title;
		if($title2 != ''){
			$title2 = $next_post->post_title;
		} else {
			$title2 = get_the_date( 'd M Y', $next_post->ID );
		}
	?>
    <a href="<?php echo esc_url(get_permalink( $next_post->ID )); ?>" class="post-pagi right-bor"><?php echo esc_html($title2); ?><i class="fa fa-angle-right"></i></a>	
	<?php } ?>
	
	</div>
	
	<?php
}

add_filter('loop_shop_columns', 'gocourier_loop_columns');
if (!function_exists('gocourier_loop_columns')) {
	function gocourier_loop_columns() {
		return (function_exists('ot_get_option'))? ot_get_option( 'product_column', 3 ) : 3; // 3 products per row
	}
}

remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
add_action( 'woocommerce_before_shop_loop_item_title', 'gocourier_get_product_thumbnail', 10 );

function gocourier_get_product_thumbnail( $size = 'shop_gocourier', $deprecated1 = 0, $deprecated2 = 0 ) {
	global $post;
	global $product;
	
	if ( has_post_thumbnail() ) {
		$image = get_the_post_thumbnail( $post->ID, $size );
	} elseif ( wc_placeholder_img_src() ) {
		$image = wc_placeholder_img( $size );
	}
	
	?><div class="shop-image entry">
		<a href="<?php echo esc_url(get_permalink()); ?>"><?php echo wp_kses($image, array('img'=>array('class'=>array(), 'width'=>array(), 'height'=>array(), 'alt'=>array(), 'src'=>array(), 'title'=>array(), 'rel'=>array()))); ?></a>
		<div class="magnifier">
			<div class="shop-buttons">
			<?php echo apply_filters( 'woocommerce_loop_add_to_cart_link',
				sprintf( '<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" data-quantity="%s" class="btn btn-white %s">%s</a>',
					esc_url( $product->add_to_cart_url() ),
					esc_attr( $product->get_id() ),
					esc_attr( $product->get_sku() ),
					esc_attr( isset( $quantity ) ? $quantity : 1 ),
					$product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
					esc_html( $product->add_to_cart_text() )
				),
			$product );
			?>
			</div>
		</div>
	</div>
	
	<?php
}

remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
add_action( 'woocommerce_after_shop_loop_item_title', 'gocourier_template_loop_category', 5 );

function gocourier_template_loop_category(){
	global $post;
	echo get_the_term_list( $post->ID, 'product_cat', '<span>' .esc_html__('In: ', 'gocourier'), ', ', '</span>' );
}

add_filter( 'woocommerce_output_related_products_args', 'gocourier_related_products_args' );
function gocourier_related_products_args( $args ) {
	$args['posts_per_page'] = (function_exists('ot_get_option'))? ot_get_option( 'related_product', 4 ) : 4; // 4 related products
    $args['columns'] = (function_exists('ot_get_option'))? ot_get_option( 'related_product_column', 4 ) : 4; // arranged in 2 columns
    return $args;
}

remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );

remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
add_action( 'woocommerce_shop_loop_item_title', 'gocourier_template_loop_product_title', 10 );

function gocourier_template_loop_product_title(){
	echo '<div class="shop-title"><h3><a href="' .esc_url(get_permalink()). '">' . get_the_title() . '</a></h3></div>';
}

function gocourier_loop_shop_per_page($cols){
	return 9;
}

add_filter( 'loop_shop_per_page', 'gocourier_loop_shop_per_page', 20 );

function gocourier_ajax_login_init(){

    wp_register_script('gocourier-ajax-login-script', get_template_directory_uri() . '/js/ajax-login-script.js', array('jquery') ); 
    wp_enqueue_script('gocourier-ajax-login-script');

    wp_localize_script( 'gocourier-ajax-login-script', 'ajax_login_object', array( 
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'redirecturl' => home_url('/'),
        'loadingmessage' => esc_html__('Sending user info, please wait...', 'gocourier')
    ));

    // Enable the user with no privileges to run ajax_login() in AJAX
    add_action( 'wp_ajax_nopriv_ajaxlogin', 'gocourier_ajax_login' );
}

// Execute the action only if the user isn't logged in
if (!is_user_logged_in()) {
    add_action('init', 'gocourier_ajax_login_init');
}

function gocourier_ajax_login(){

    // First check the nonce, if it fails the function will break
    check_ajax_referer( 'ajax-login-nonce', 'security' );

    // Nonce is checked, get the POST data and sign user on
    $info = array();
    $info['user_login'] = $_POST['username'];
    $info['user_password'] = $_POST['password'];
    $info['remember'] = true;

    $user_signon = wp_signon( $info, false );
    if ( is_wp_error($user_signon) ){
        echo json_encode(array('loggedin'=>false, 'message'=>esc_html__('Wrong username or password.', 'gocourier')));
    } else {
        echo json_encode(array('loggedin'=>true, 'message'=>esc_html__('Login successful, redirecting...', 'gocourier')));
    }

    die();
}

// To change add to cart text on single product page
add_filter( 'woocommerce_product_single_add_to_cart_text', 'gocourier_custom_single_add_to_cart_text' ); 
function gocourier_custom_single_add_to_cart_text() {
    return esc_html__( 'Order Courier', 'gocourier' ); 
}

// To change add to cart text on product archives(Collection) page
add_filter( 'woocommerce_product_add_to_cart_text', 'gocourier_custom_product_add_to_cart_text' );  
function gocourier_custom_product_add_to_cart_text() {
    return esc_html__( 'Order Courier', 'gocourier' );
}

