<?php
/**
 * footer widget area
 *
 *
 * @package WordPress
 * @subpackage gocourier
 * @since gocourier 1.0
 */
?>
<?php
if( function_exists( 'ot_get_option' ) ):
	$footer_widget_area = ot_get_option( 'footer_widget_area', 'on' );
	if( $footer_widget_area == 'on' ): ?>
	<div class="footer-widget-wrap">
    	<?php
        $col_class = ot_get_option( 'footer_widget_box', 4 );
		$footer_col_class = 12/$col_class;
		?>
        <div class="container">
            <div class="row">
                
                    <?php				
                        for( $i = 1; $i <= $col_class; $i++ ):
                            if ( is_active_sidebar( 'footer-'.$i ) ) : ?>
                            <div class="col-lg-<?php echo esc_attr($footer_col_class); ?> col-md-<?php echo esc_html($footer_col_class); ?> col-sm-6 col-xs-12 footer-widget-area">
                                <div class="widget-area-footer" role="complementary">
                                    <?php dynamic_sidebar( 'footer-'.$i ); ?>
                                </div><!-- .widget-area -->
                            </div>
                            <?php
                            endif;
                        endfor; 
                    endif; ?>
                
            </div>
        </div>
	</div>
	<?php
endif;	//if( function_exists( 'ot_get_option' ) ):
?>