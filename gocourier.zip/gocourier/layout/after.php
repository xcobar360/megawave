<?php
	if(is_page()) {
		$layout = get_post_meta( get_the_ID(), 'page_layout', true );
		if($layout != ''){
			$layout = $layout;
		} else {
			$layout = 'rs';
		}
	}
	elseif(is_single()){
		$layout = (function_exists('ot_get_option'))? ot_get_option( 'single_layout', 'rs' ) : 'rs';
	}
	else {
		$layout = (function_exists('ot_get_option'))? ot_get_option( 'blog_layout', 'rs' ) : 'rs';
	}
	
	if ( class_exists( 'woocommerce' ) ){
		if( is_product() ){
			$layout = (function_exists('ot_get_option'))? ot_get_option( 'product_layout', 'full' ) : 'full';
		}
		elseif( is_woocommerce() ){
			$layout = (function_exists('ot_get_option'))? ot_get_option( 'shop_layout', 'rs' ) : 'rs';
		}
	}
	

?>		
        </div>
        <?php if( $layout != 'full' ): ?>
        <div id="sidebar" class="col-md-3 col-sm-12 col-xs-12">
            <?php get_sidebar(); ?>			
        </div>
        <?php endif; // endif ?>  

    </div>
</div>
<!-- Content Wrap -->