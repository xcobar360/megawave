<?php
		$container = 'container';
		if(is_page()){
			$layout = get_post_meta( get_the_ID(), 'page_layout', true );
			if($layout != ''){
				$layout = $layout;
			} else {
				$layout = 'rs';
			}
		}	
		elseif(is_single()){
			$layout = (function_exists('ot_get_option'))? ot_get_option( 'single_layout', 'rs' ) : 'rs';
		}
		else{
			$layout = (function_exists('ot_get_option'))? ot_get_option( 'blog_layout', 'rs' ) : 'rs';
		}
		
		if ( class_exists( 'woocommerce' ) ){
			if( is_product() ){
				$layout = (function_exists('ot_get_option'))? ot_get_option( 'product_layout', 'full' ) : 'full';
			}
			elseif( is_woocommerce() ){
				$layout = (function_exists('ot_get_option'))? ot_get_option( 'shop_layout', 'rs' ) : 'rs';
			}
		}
		
		if( $layout == 'full' ){
			$container_class = 'col-md-12 col-lg-12 col-sm-12 col-xs-12';
		}
		else{
			$container_class = 'col-lg-9 col-md-9 col-sm-12 col-xs-12';
			$container_class .= ( $layout == 'ls' )? ' pull-right' : '';
		}
	?>

<!-- Content Wrap -->
		<div class="section white page-content">
            <div class="<?php echo esc_attr($container); ?>">
                <div id="content" class="<?php echo esc_attr($container_class); ?>">
