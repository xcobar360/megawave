<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    <div class="shop-box">
    	<?php if ( is_sticky() && is_home() && ! is_paged() ) : ?>
            <div class="post-meta sticky-posts">
            <?php $sticky_post_text = (function_exists('ot_get_option'))? ot_get_option( 'sticky_post_text', 'Featured' ) : 'Featured'; ?>
            <div class="sticky-content"><?php printf( '<span class="sticky-post">%s</span>', $sticky_post_text ); ?></div>
            </div>
		<?php endif; ?>
        <div class="blog-title">
            <?php the_title( sprintf( '<h3><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' ); ?>
        </div><!-- end blog-title -->
        <div class="meta">
		<?php
		$categories_list = get_the_category_list( esc_html_x( ', ', 'Used between list items, there is a comma.', 'gocourier' ) );
		if ( $categories_list && gocourier_categorized_blog() ): ?>
		<?php printf( '<span>%1$s </span>%2$s</span>', esc_html__( 'In : ', 'gocourier' ), $categories_list ); ?>
		<?php
		endif;
		?>
        <span><?php echo esc_html__('Comments : ', 'gocourier'); ?><?php comments_number( '0', '1', '%' ); ?></span>
        <span><?php echo esc_html__('Author : ', 'gocourier'); ?><a href="<?php echo esc_url( get_author_posts_url(get_the_author_meta( 'ID' ))); ?>"><?php echo get_the_author_meta('display_name'); ?></a></span>
        <span><?php echo esc_html__('Date : ', 'gocourier'); ?><a href="<?php echo esc_url(get_permalink()); ?>"><?php echo get_the_date( 'd M Y' ); ?></a></span>
        </div><!-- end meta -->
        <div class="shop-image entry entry-blog">
            <?php gocourier_post_thumb( 1000, 600, true, false ); ?>
        </div>
        
        <?php if ( is_search()) : ?>
            <div class="blog-desc-small"><?php the_excerpt(); ?></div>
        <?php else : ?>
            <div class="blog-desc-small">
            <?php the_content(sprintf(esc_html__( 'Read More', 'gocourier' ) ) ); ?>
            </div>
        <?php endif; ?>
        <?php if(is_single()): ?>        
			<?php
            wp_link_pages( array(
                'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'gocourier' ) . '</span>',
                'after'       => '</div>',
                'link_before' => '<span>',
                'link_after'  => '</span>',
                'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'gocourier' ) . ' </span>%',
                'separator'   => '<span class="screen-reader-text">, </span>',
            ) );
            ?>
            <div class="edit_post_link">
                <?php edit_post_link( esc_html__( 'Edit', 'gocourier' ), '<span class="edit-link">', '</span>' ); ?>
            </div>
        
			<?php
            $tags_list = get_the_tag_list( '<ul class="single-blog-tags"><li>' .esc_html__('Tags:', 'gocourier') .'</li><li>','</li><li>','</li></ul>');
            if ( $tags_list ): ?>
                <div class="blog-tags">
                    <?php echo wp_kses( 
                      $tags_list, 
                      // Only allow ul, li tags
                      array(
                        'ul' => array(
                          'class' => array()
                        ),
                        'li' => array(
                          'class' => array()
                        ),
                        'a' => array(
                          'href' => array()
                        ),
                      )
                    ); ?>
                </div> 
            <?php 
            endif;
            ?>
        
        <?php endif; ?>
            
    </div><!-- end blog-wrap -->
</div>